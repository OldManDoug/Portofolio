package oodjassignment.staff;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import oodjassignment.FileHandler;

public class TechnicianHomePage extends JFrame {
    private JTable taskTable;
    private DefaultTableModel tableModel;
    private Technician currentTech;

    // Modern Flat Theme Colors
    private final Color COLOR_PRIMARY_DARK = new Color(45, 52, 54);     // Deep Slate
    private final Color COLOR_SECONDARY_DARK = new Color(53, 59, 72);   // Charcoal
    private final Color COLOR_ACCENT_BLUE = new Color(9, 132, 227);     // Electric Blue
    private final Color COLOR_LOGOUT_RED = new Color(214, 48, 49);      // Muted Red
    private final Color COLOR_BG_LIGHT = new Color(245, 246, 250);      // Soft White Background
    private final Font FONT_HEADER = new Font("Segoe UI", Font.BOLD, 14);
    private final Font FONT_BODY = new Font("Segoe UI", Font.PLAIN, 13);

    public TechnicianHomePage(Technician tech) {
        this.currentTech = tech;
        
        setTitle("Technician Dashboard - " + tech.getName());
        setSize(1150, 600); // Expanded slightly for better UI scaling and layout padding
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(COLOR_BG_LIGHT);

        // --- HEADER PANEL ---
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(COLOR_PRIMARY_DARK);
        headerPanel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        
        JLabel lblWelcome = new JLabel("🔧 Technician Workstation  |  Logged in as: " + tech.getName() + " (" + tech.getId() + ")");
        lblWelcome.setFont(FONT_HEADER);
        lblWelcome.setForeground(Color.WHITE);
        headerPanel.add(lblWelcome, BorderLayout.WEST);
        add(headerPanel, BorderLayout.NORTH);

        // --- TABLE SYSTEM ASSEMBLY ---
        String[] columns = {"Service ID", "Date", "Car Plate", "Service Type", "Status", "Payment Status"};
        tableModel = new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
        
        taskTable = new JTable(tableModel);
        taskTable.setFont(FONT_BODY);
        taskTable.setRowHeight(32);
        taskTable.setGridColor(new Color(220, 221, 225));
        taskTable.setSelectionBackground(new Color(116, 185, 255));
        taskTable.setSelectionForeground(Color.BLACK);
        taskTable.setShowVerticalLines(false); // Clean modern look without vertical borders

        // Header Styling
        JTableHeader tableHeader = taskTable.getTableHeader();
        tableHeader.setFont(FONT_HEADER);
        tableHeader.setBackground(COLOR_SECONDARY_DARK);
        tableHeader.setForeground(Color.WHITE);
        tableHeader.setPreferredSize(new Dimension(tableHeader.getWidth(), 38));
        tableHeader.setReorderingAllowed(false);

        // Custom Cell Renderers (Alignment & Colored Statuses)
        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(JLabel.CENTER);
        
        for (int i = 0; i < taskTable.getColumnCount(); i++) {
            if (i != 3) { // Center everything except service type description
                taskTable.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
            }
        }
        
        // Dynamically Inject Status Alert Color Colors into Column index 4
        taskTable.getColumnModel().getColumn(4).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                setHorizontalAlignment(JLabel.CENTER);
                setFont(FONT_HEADER.deriveFont(12f)); // Make status text pop a bit more
                
                if (value != null) {
                    String status = value.toString().trim();
                    if (status.equalsIgnoreCase("Pending")) {
                        c.setForeground(new Color(230, 126, 34)); // Orange
                    } else if (status.equalsIgnoreCase("In-Progress")) {
                        c.setForeground(new Color(41, 128, 185)); // Deep Blue
                    } else if (status.equalsIgnoreCase("Completed")) {
                        c.setForeground(new Color(39, 174, 96));  // Emerald Green
                    } else if (status.equalsIgnoreCase("Cancelled")) {
                        c.setForeground(COLOR_LOGOUT_RED);       // Red
                    }
                }
                
                // Keep background consistent with standard selection styling rules
                if (isSelected) {
                    c.setBackground(new Color(116, 185, 255));
                } else {
                    c.setBackground(Color.WHITE);
                }
                return c;
            }
        });

        refreshTable();
        
        JScrollPane tableScrollPane = new JScrollPane(taskTable);
        tableScrollPane.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));
        tableScrollPane.getViewport().setBackground(Color.WHITE);
        add(tableScrollPane, BorderLayout.CENTER);

        // --- BUTTONS FOOTER CONTROLS ---
        JPanel footerContainer = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 15));
        footerContainer.setBackground(COLOR_BG_LIGHT);
        footerContainer.setBorder(BorderFactory.createEmptyBorder(5, 10, 15, 10));

        JButton btnRemarks = createStyledButton("View Customer Remarks", COLOR_ACCENT_BLUE);
        JButton btnInternalNotes = createStyledButton("Internal Progress", COLOR_SECONDARY_DARK);
        JButton btnStatus = createStyledButton("Update Status", COLOR_SECONDARY_DARK);
        JButton btnFinalSolution = createStyledButton("Submit Final Solution", COLOR_SECONDARY_DARK);
        JButton btnViewSolutions = createStyledButton("View My Solutions", COLOR_SECONDARY_DARK); 
        JButton btnProfile = createStyledButton("My Profile", COLOR_SECONDARY_DARK);
        JButton btnLogout = createStyledButton("Logout", COLOR_LOGOUT_RED);
        
        footerContainer.add(btnRemarks);
        footerContainer.add(btnInternalNotes);
        footerContainer.add(btnStatus);
        footerContainer.add(btnFinalSolution);
        footerContainer.add(btnViewSolutions);
        footerContainer.add(btnProfile);
        footerContainer.add(btnLogout);
        add(footerContainer, BorderLayout.SOUTH);

        // --- CORE APPLICATION ACTION LOGIC BLOCKS ---

        // View Customer Remarks Logic
        btnRemarks.addActionListener(e -> {
            int row = taskTable.getSelectedRow();
            if (row == -1) {
                showWarning("Please select an assignment task entry from the table first.");
                return;
            }

            String targetPlate = ((String) tableModel.getValueAt(row, 2)).trim().toUpperCase();
            FileHandler.loadFeedbackFromFile();
            
            StringBuilder customerRemarksBuilder = new StringBuilder();
            int matchCount = 0;
            String searchPattern = "REMARK - Plate: " + targetPlate + " |";

            for (String line : FileHandler.allFeedback) {
                if (line.contains(searchPattern)) {
                    try {
                        String details = line.substring(line.indexOf("Details:") + 8).trim();
                        customerRemarksBuilder.append("💬 ").append(details).append("\n")
                                              .append("--------------------------------------------------\n\n");
                        matchCount++;
                    } catch (Exception ex) {
                        // Gracefully absorb text parsing index structural anomalies
                    }
                }
            }

            if (matchCount == 0) {
                showInfo("No matching operational feedback comments found for plate: " + targetPlate);
            } else {
                JTextArea txtArea = createCustomPopupTextArea(customerRemarksBuilder.toString(), 250);
                JOptionPane.showMessageDialog(this, new JScrollPane(txtArea), "Customer Remarks Found (" + targetPlate + ")", JOptionPane.PLAIN_MESSAGE);
            }
        });

        // Internal Notes Logic 
        btnInternalNotes.addActionListener(e -> {
            int row = taskTable.getSelectedRow();
            if (row == -1) {
                showWarning("Select a task to update progress.");
                return;
            }

            String serviceId = (String) tableModel.getValueAt(row, 0);
            FileHandler.loadServiceHistories(); 
            
            for (ServiceHistories sh : FileHandler.allServiceHistories) {
                if (sh.getServiceId().equals(serviceId)) {
                    String existingNotes = (sh.getTechnicalNotes() == null || sh.getTechnicalNotes().equals("None")) 
                                           ? "" : sh.getTechnicalNotes();
                    
                    JTextArea textArea = createCustomPopupTextArea(existingNotes.replace("[NL]", "\n"), 180);
                    textArea.setEditable(true); // Allow active technician input entries

                    JPanel panel = new JPanel(new BorderLayout(5, 5));
                    JLabel lblInstruction = new JLabel("Update technical progress notes for internal evaluation logs:");
                    lblInstruction.setFont(FONT_BODY);
                    panel.add(lblInstruction, BorderLayout.NORTH);
                    panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

                    int result = JOptionPane.showConfirmDialog(this, panel, "Internal Work Log (" + serviceId + ")", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                    
                    if (result == JOptionPane.OK_OPTION) {
                        String newNote = textArea.getText().trim();
                        sh.setTechnicalNotes(newNote.isEmpty() ? "None" : newNote);
                        saveUpdatedHistories();
                        showInfo("Notes saved to log sequence file successfully.");
                    }
                    break;
                }
            }
        });

        // Status Adjustment Logic
        btnStatus.addActionListener(e -> {
            int selectedRow = taskTable.getSelectedRow();
            if (selectedRow == -1) {
                showWarning("Please select a task tracking entry.");
                return;
            }

            String serviceId = (String) tableModel.getValueAt(selectedRow, 0);
            String[] options = {"Pending", "In-Progress", "Completed", "Cancelled"};
            
            // Re-styled basic input dialog setup
            String newStatus = (String) JOptionPane.showInputDialog(this, 
                    "Update current operation status stage for " + serviceId + ":", "Status Update",
                    JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

            if (newStatus != null) {
                for (ServiceHistories sh : FileHandler.allServiceHistories) {
                    if (sh.getServiceId().equals(serviceId)) {
                        sh.setStatus(newStatus);
                        break;
                    }
                }
                saveUpdatedHistories();
                refreshTable();
            }
        });

        // Submit Final Solution Details Logic 
        btnFinalSolution.addActionListener(e -> {
            int row = taskTable.getSelectedRow();
            if (row == -1) {
                showWarning("Select a task tracking entry first.");
                return;
            }

            String serviceId = (String) tableModel.getValueAt(row, 0);
            
            FileHandler.loadFeedbackFromFile();
            for (String line : FileHandler.allFeedback) {
                if (line.contains("FINAL SOLUTION - Service ID: " + serviceId)) {
                    JOptionPane.showMessageDialog(this, "A final solution has already been registered for this service code.", "Task Locked", JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }

            String solution = JOptionPane.showInputDialog(this, "Enter the diagnostic outcome / final resolution details for " + serviceId + ":");
            
            if (solution != null && !solution.trim().isEmpty()) {
                FileHandler.saveComment("FINAL SOLUTION - Service ID: " + serviceId + " | Tech: " + currentTech.getName() + " | Details: " + solution.trim());
                showInfo("Final resolution submitted to management log database.");
            }
        });

        // View Past Logs Solution Log Logic
        btnViewSolutions.addActionListener(e -> {
            FileHandler.loadFeedbackFromFile();
            StringBuilder myLogs = new StringBuilder();
            int counter = 0;
            String matchKey = "| Tech: " + currentTech.getName() + " |";
            
            for (String line : FileHandler.allFeedback) {
                if (line.contains("FINAL SOLUTION - Service ID:") && line.contains(matchKey)) {
                    try {
                        String sId = line.substring(line.indexOf("Service ID:") + 11, line.indexOf("| Tech:")).trim();
                        String details = line.substring(line.indexOf("Details:") + 8).trim();
                        
                        myLogs.append("🛠️ Service ID: ").append(sId).append("\n")
                              .append("📋 Resolution: ").append(details).append("\n")
                              .append("------------------------------------------------------------\n\n");
                        counter++;
                    } catch (Exception ex) {
                        // Skip minor formatting discrepancies
                    }
                }
            }
            
            if (counter == 0) {
                showInfo("You have not logged any historical solutions inside the data file yet.");
            } else {
                JTextArea logArea = createCustomPopupTextArea(myLogs.toString(), 300);
                JOptionPane.showMessageDialog(this, new JScrollPane(logArea), "Your Performance History Log", JOptionPane.PLAIN_MESSAGE);
            }
        });

        btnProfile.addActionListener(e -> new EditProfileGUI(currentTech).setVisible(true));

        btnLogout.addActionListener(e -> {
            this.dispose();
            new oodjassignment.StartPage().setVisible(true);
        });
    }

    // --- UI FACTORY METHOD HELPERS ---
    
    private JButton createStyledButton(String text, Color baseColor) {
        JButton btn = new JButton(text);
        btn.setFont(FONT_BODY.deriveFont(Font.BOLD, 12f));
        btn.setForeground(Color.WHITE);
        btn.setBackground(baseColor);
        btn.setFocusPainted(false);
        btn.setBorderPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setMargin(new Insets(8, 16, 8, 16));
        
        // Soft hover effect logic mapping
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor.brighter());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(baseColor);
            }
        });
        return btn;
    }

    private JTextArea createCustomPopupTextArea(String content, int preferredHeight) {
        JTextArea txt = new JTextArea(content);
        txt.setFont(new Font("Consolas", Font.PLAIN, 13)); // Monospace looks much cleaner for technical notes
        txt.setEditable(false);
        txt.setLineWrap(true);
        txt.setWrapStyleWord(true);
        txt.setBackground(new Color(248, 249, 250));
        txt.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        return txt;
    }

    private void showWarning(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Selection Required", JOptionPane.WARNING_MESSAGE);
    }

    private void showInfo(String msg) {
        JOptionPane.showMessageDialog(this, msg, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        FileHandler.loadServiceHistories();
        for (ServiceHistories sh : FileHandler.allServiceHistories) {
            if (sh.getTechnicianId().trim().equalsIgnoreCase(currentTech.getId().trim())) {
                tableModel.addRow(new Object[]{
                    sh.getServiceId(), sh.getDate(), sh.getCarPlate().toUpperCase(),
                    sh.getServiceType(), sh.getStatus(), sh.getPaymentStatus()
                });
            }
        }
    }

    private void saveUpdatedHistories() {
        try (java.io.PrintWriter writer = new java.io.PrintWriter(new java.io.FileWriter("ServiceHistories.txt"))) {
            for (ServiceHistories sh : FileHandler.allServiceHistories) {
                String notes = (sh.getTechnicalNotes() == null || sh.getTechnicalNotes().isEmpty()) ? "None" : sh.getTechnicalNotes();
                String remarks = sh.getRemarks() != null ? sh.getRemarks().replace("\n", "[NL]") : "";
                String customerRemarks = sh.getCustomerRemarks() != null ? sh.getCustomerRemarks().replace("\n", "[NL]") : "";
                String custName = sh.getCustomerName() != null ? sh.getCustomerName() : "";
                
                notes = notes.replace("\n", "[NL]"); 
                
                writer.println(sh.getServiceId() + "," + sh.getDate() + "," + 
                               sh.getEndDate() + "," + sh.getCarPlate() + "," + 
                               custName + "," + sh.getTechnicianId() + "," + 
                               sh.getServiceType() + "," + sh.getStatus() + "," + 
                               sh.getPaymentStatus() + "," + remarks + "," + 
                               customerRemarks + "," + notes);
            }
        } catch (java.io.IOException ex) {
            ex.printStackTrace();
        }
    }
}