package oodjassignment.staff;

import oodjassignment.FileHandler;

public class Manager extends Staff {

    public Manager(String id, String name, String password) {
        super(id, name, password, "Manager");
    }

    public String searchCustomer(String name) {
        return FileHandler.displayCustomer(FileHandler.checkName(name));
    }

    
    public String searchStaff(String staffName) {
        return FileHandler.displayStaffDetails(FileHandler.checkStaffName(staffName));
    }
}


