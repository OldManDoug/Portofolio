package oodjassignment.staff;

public class CounterStaff extends Staff {
    public CounterStaff(String id, String name, String password) {
        super(id, name, password, "Counter Staff");
    }
}
