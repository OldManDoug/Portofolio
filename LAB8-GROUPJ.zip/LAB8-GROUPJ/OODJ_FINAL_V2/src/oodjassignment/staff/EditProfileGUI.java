package oodjassignment.staff;

import javax.swing.*;
import java.awt.*;
import oodjassignment.FileHandler;

public class EditProfileGUI extends JFrame {
    public EditProfileGUI(Staff s) {
        setTitle("Edit Profile - " + s.getName());
        setSize(350, 200);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(4, 2, 10, 10));

        add(new JLabel(" ID:"));
        add(new JLabel(s.getId()));
        
        add(new JLabel(" Name:"));
        add(new JLabel(s.getName()));
        
        add(new JLabel(" New Password:"));
        JTextField txtPass = new JTextField(s.getPassword());
        add(txtPass);

        JButton btnCancel = new JButton("Cancel");
        JButton btnSave = new JButton("Save Changes");
        add(btnCancel);
        add(btnSave);

        btnSave.addActionListener(e -> {
            if(txtPass.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Password cannot be empty!");
                return;
            }
            s.setPassword(txtPass.getText());
            FileHandler.saveStaffToFile(); 
            JOptionPane.showMessageDialog(this, "Profile Updated Successfully!");
            this.dispose();
        });

        btnCancel.addActionListener(e -> this.dispose());
    }
}
