package oodjassignment.staff;

import oodjassignment.Car;
import oodjassignment.Customer;
import oodjassignment.CustomerPaymentHistory;
import oodjassignment.StartPage;
import oodjassignment.FileHandler;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class CounterStaffHomePage extends JFrame {
    private final Staff currentStaff;
    private final DefaultTableModel tableModel;
    private final JTable appointmentTable;
    private JFrame customerFrame;

    public CounterStaffHomePage(Staff staff) {
        this.currentStaff = staff;

        setTitle("Counter Staff Dashboard - " + staff.getName());
        setSize(950, 520);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout(8, 8));

        JLabel header = new JLabel("Counter Staff: " + staff.getName(), JLabel.CENTER);
        header.setFont(new Font("Arial", Font.BOLD, 20));
        add(header, BorderLayout.NORTH);

        // Search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search/Filter Customers"));
        JTextField searchField = new JTextField(20);
        JComboBox<String> searchCriteria = new JComboBox<>(new String[]{"Name", "Phone", "Car Plate"});
        JButton btnSearch = new JButton("Search");
        JButton btnClear = new JButton("Clear");

        searchPanel.add(new JLabel("Search by:"));
        searchPanel.add(searchCriteria);
        searchPanel.add(searchField);
        searchPanel.add(btnSearch);
        searchPanel.add(btnClear);

        tableModel = new DefaultTableModel(new String[]{"Service ID", "Date/Time", "Car Plate", "Tech ID", "Service", "Status", "Payment"}, 0);
        appointmentTable = new JTable(tableModel);
        appointmentTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.add(searchPanel, BorderLayout.NORTH);
        centerPanel.add(new JScrollPane(appointmentTable), BorderLayout.CENTER);
        add(centerPanel, BorderLayout.CENTER);

        JPanel controls = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        JButton btnBook = new JButton("Create Appointment");
        JButton btnPay = new JButton("Collect Payment");
        JButton btnReceipt = new JButton("View Receipt");
        JButton btnEditProfile = new JButton("Edit Profile");
        JButton btnCustomers = new JButton("View Customers");
        JButton btnLogout = new JButton("Logout");

        btnBook.addActionListener(e -> handleCreateAppointment());
        btnPay.addActionListener(e -> handleCollectPayment());
        btnReceipt.addActionListener(e -> handleViewReceipt());
        btnEditProfile.addActionListener(e -> new EditProfileGUI(currentStaff).setVisible(true));
        btnCustomers.addActionListener(e -> handleViewCustomers());
        btnLogout.addActionListener(e -> {
            if (customerFrame != null) customerFrame.dispose();
            this.dispose();
            new oodjassignment.StartPage().setVisible(true);
        });

        btnSearch.addActionListener(e -> handleSearch(searchField, searchCriteria));
        btnClear.addActionListener(e -> {
            searchField.setText("");
            refreshTable();
        });

        controls.add(btnBook);
        controls.add(btnPay);
        controls.add(btnReceipt);
        controls.add(btnEditProfile);
        controls.add(btnCustomers);
        controls.add(btnLogout);

        add(controls, BorderLayout.SOUTH);

        refreshTable();
    }

    private void refreshTable() {
        tableModel.setRowCount(0);
        FileHandler.loadServiceHistories();
   
        for (ServiceHistories sh : FileHandler.allServiceHistories) {

            tableModel.addRow(new Object[]{
                    sh.getServiceId(),
                    sh.getDate(),
                    sh.getCarPlate(),
                   
                    sh.getTechnicianId(),
                    sh.getServiceType(),
                    sh.getStatus(),
                    sh.getPaymentStatus()
            });
        }
    }

    private void handleCreateAppointment() {
        FileHandler.loadCustFromFile();
        FileHandler.loadStaffFromFile();
        FileHandler.loadServiceHistories();

        if (FileHandler.allCust.isEmpty()) {
            JOptionPane.showMessageDialog(this, "No customers registered yet.", "Create Appointment", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // Create form components
        JComboBox<String> customerCombo = new JComboBox<>();
        for (Customer c : FileHandler.allCust) {
            customerCombo.addItem(c.getCustID() + " - " + c.getName());
        }

        JSpinner dateSpinner = new JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.DAY_OF_MONTH));
        dateSpinner.setEditor(new JSpinner.DateEditor(dateSpinner, "yyyy-MM-dd"));

        JSpinner timeSpinner = new JSpinner(new SpinnerDateModel(new Date(), null, null, Calendar.MINUTE));
        timeSpinner.setEditor(new JSpinner.DateEditor(timeSpinner, "HH:mm"));

        JComboBox<String> serviceType = new JComboBox<>(new String[]{"Normal", "Major", "GeneralRepair", "Inspection"});

        // Show form in a loop to preserve data on validation errors
        while (true) {
            Object[] inputs = {
                    "Customer:", customerCombo,
                    "Appointment Date:", dateSpinner,
                    "Appointment Time:", timeSpinner,
                    "Service Type:", serviceType
            };

            int choice = JOptionPane.showConfirmDialog(this, inputs, "New Appointment", JOptionPane.OK_CANCEL_OPTION);
            if (choice != JOptionPane.OK_OPTION) {
                return;
            }

            String selectedCustomer = (String) customerCombo.getSelectedItem();
            if (selectedCustomer == null) return;
            String custID = selectedCustomer.split(" - ")[0];
            Customer customer = FileHandler.allCust.stream().filter(c -> c.getCustID().equals(custID)).findFirst().orElse(null);
            if (customer == null) {
                JOptionPane.showMessageDialog(this, "Customer selection invalid.", "Create Appointment", JOptionPane.ERROR_MESSAGE);
                continue;
            }

            if (customer.getCar() == null || customer.getCar().getPlateno() == null
                    || customer.getCar().getPlateno().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Selected customer has no car plate on file. Update customer data first.", "Create Appointment", JOptionPane.ERROR_MESSAGE);
                continue;
            }
            String plate = customer.getCar().getPlateno().trim().toUpperCase();
            String type = (String) serviceType.getSelectedItem();
            Date selectedDate = (Date) dateSpinner.getValue();
            Date selectedTime = (Date) timeSpinner.getValue();

            String appointmentError = validateAppointmentInput(plate, type, selectedDate, selectedTime);
            if (appointmentError != null) {
                JOptionPane.showMessageDialog(this, appointmentError, "Create Appointment", JOptionPane.ERROR_MESSAGE);
                continue;  // Loop back to form with data preserved
            }

            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
            String appointmentDateTime = dateFormat.format(selectedDate) + " " + timeFormat.format(selectedTime);

            ArrayList<Technician> available = FileHandler.getAvailableTechnicians(appointmentDateTime, type);
            if (available.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No available technicians for that slot.", "Create Appointment", JOptionPane.WARNING_MESSAGE);
                continue;  // Loop back to form with data preserved
            }

            JComboBox<String> techCombo = new JComboBox<>();
            for (Technician tech : available) {
                techCombo.addItem(tech.getId() + " - " + tech.getName());
            }

            int techChoice = JOptionPane.showConfirmDialog(this, new Object[]{"Select Technician:", techCombo}, "Choose Technician", JOptionPane.OK_CANCEL_OPTION);
            if (techChoice != JOptionPane.OK_OPTION) {
                continue;  // Loop back to form with data preserved
            }

            String techId = ((String) techCombo.getSelectedItem()).split(" - ")[0];
            FileHandler.bookAppointment(customer.getName(), plate, techId, type, appointmentDateTime, currentStaff.getName());
            refreshTable();

            JOptionPane.showMessageDialog(this, "Appointment created and assigned to " + techId + ".", "Appointment Created", JOptionPane.INFORMATION_MESSAGE);
            break;  // Exit loop on success
        }
    }

    private void handleCollectPayment() {
        int row = appointmentTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to collect payment.", "Collect Payment", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String serviceId = (String) tableModel.getValueAt(row, 0);
        FileHandler.loadServiceHistories();
        ServiceHistories sh = FileHandler.allServiceHistories.stream()
                .filter(item -> item.getServiceId().equals(serviceId))
                .findFirst().orElse(null);

        if (sh == null) {
            JOptionPane.showMessageDialog(this, "Unable to locate the selected appointment.", "Collect Payment", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (sh.getPaymentStatus().equalsIgnoreCase("Paid")) {
            JOptionPane.showMessageDialog(this, "This appointment has already been paid.", "Collect Payment", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        double amount = FileHandler.getServicePrice(sh.getServiceType());
        int confirm = JOptionPane.showConfirmDialog(this,
                "Collect RM" + amount + " for Service " + serviceId + "?",
                "Collect Payment", JOptionPane.YES_NO_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }

        CustomerPaymentHistory receipt = FileHandler.recordPayment(sh);
        if (receipt == null) {
            JOptionPane.showMessageDialog(this, "Payment could not be recorded. Verify customer details.", "Collect Payment", JOptionPane.ERROR_MESSAGE);
            return;
        }

        FileHandler.saveServiceHistories();
        refreshTable();
        JOptionPane.showMessageDialog(this, "Receipt created:\nReceipt ID: " + receipt.getReceiptId() + "\nService ID: " + receipt.getServiceId() + "\nAmount: RM" + receipt.getAmount(), "Payment Collected", JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleViewReceipt() {
        int row = appointmentTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to view its receipt.", "View Receipt", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String serviceId = (String) tableModel.getValueAt(row, 0);
        FileHandler.loadServiceHistories();
        ServiceHistories sh = FileHandler.allServiceHistories.stream()
                .filter(item -> item.getServiceId().equals(serviceId))
                .findFirst().orElse(null);

        if (sh == null) {
            JOptionPane.showMessageDialog(this, "Unable to locate the selected appointment.", "View Receipt", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!sh.getPaymentStatus().equalsIgnoreCase("Paid")) {
            JOptionPane.showMessageDialog(this, "No receipt exists yet for this appointment.", "View Receipt", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        CustomerPaymentHistory receipt = FileHandler.findReceiptByServiceId(serviceId);
        if (receipt == null) {
            JOptionPane.showMessageDialog(this, "Receipt record not found. Please collect payment first.", "View Receipt", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String receiptText = FileHandler.displayReceipt(receipt);
        JTextArea textArea = new JTextArea(receiptText);
        textArea.setEditable(false);
        JOptionPane.showMessageDialog(this, new JScrollPane(textArea), "Receipt Details", JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleViewCustomers() {
        FileHandler.loadCustFromFile();

        if (customerFrame != null) customerFrame.dispose();
        customerFrame = new JFrame("Customer Management");
        customerFrame.setSize(900, 450);
        customerFrame.setLocationRelativeTo(this);
        customerFrame.setLayout(new BorderLayout(8, 8));

        DefaultTableModel customerModel = new DefaultTableModel(new String[]{"ID", "Name", "Phone", "Email", "Car Plate", "Gender", "Address"}, 0);
        JTable customerTable = new JTable(customerModel);
        customerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        refreshCustomerTable(customerModel);

        JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 10));
        JButton btnCreate = new JButton("Create");
        JButton btnEdit = new JButton("Edit");
        JButton btnDelete = new JButton("Delete");
        JButton btnViewHistory = new JButton("View Service History");
        JButton btnRefresh = new JButton("Refresh");
        JButton btnClose = new JButton("Close");

        btnCreate.addActionListener(e -> showCustomerDialog(null, customerModel));
        btnEdit.addActionListener(e -> {
            int selectedRow = customerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(customerFrame, "Please select a customer to edit.", "Edit Customer", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String custID = (String) customerModel.getValueAt(selectedRow, 0);
            Customer cust = findCustomerById(custID);
            if (cust != null) {
                showCustomerDialog(cust, customerModel);
            }
        });
        btnDelete.addActionListener(e -> {
            int selectedRow = customerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(customerFrame, "Please select a customer to delete.", "Delete Customer", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String custID = (String) customerModel.getValueAt(selectedRow, 0);
            Customer cust = findCustomerById(custID);
            if (cust == null) return;

            int confirm = JOptionPane.showConfirmDialog(customerFrame,
                    "Delete customer " + cust.getName() + "? This cannot be undone.",
                    "Delete Customer", JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            FileHandler.archiveDeletedCustomer(cust, currentStaff != null ? currentStaff.getName() : "CounterStaff");
            FileHandler.allCust.remove(cust);
            FileHandler.saveCustomerDtToFile();
            refreshCustomerTable(customerModel);
        });
        btnViewHistory.addActionListener(e -> {
            int selectedRow = customerTable.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(customerFrame, "Please select a customer to view service history.", "View Service History", JOptionPane.WARNING_MESSAGE);
                return;
            }
            String custID = (String) customerModel.getValueAt(selectedRow, 0);
            Customer cust = findCustomerById(custID);
            if (cust != null) {
                showCustomerServiceHistory(cust);
            }
        });
        btnRefresh.addActionListener(e -> {
            FileHandler.loadCustFromFile();
            refreshCustomerTable(customerModel);
        });
        btnClose.addActionListener(e -> customerFrame.dispose());

        actionPanel.add(btnCreate);
        actionPanel.add(btnEdit);
        actionPanel.add(btnDelete);
        actionPanel.add(btnViewHistory);
        actionPanel.add(btnRefresh);
        actionPanel.add(btnClose);

        customerFrame.add(new JScrollPane(customerTable), BorderLayout.CENTER);
        customerFrame.add(actionPanel, BorderLayout.SOUTH);
        customerFrame.setVisible(true);
    }

    private void refreshCustomerTable(DefaultTableModel model) {
    model.setRowCount(0);
    // Always make sure we show the freshest data array currently sitting inside FileHandler
    for (Customer c : FileHandler.allCust) {
        if (c != null) {
            model.addRow(new Object[]{
                    c.getCustID(),
                    c.getName(),
                    c.getPhoneNo(),
                    c.getEmail(),
                    c.getCar() != null ? c.getCar().getPlateno() : "",
                    c.getGender(),
                    c.getAddress()
            });
        }
    }
}

    private Customer findCustomerById(String custID) {
        return FileHandler.allCust.stream()
                .filter(c -> c.getCustID().equals(custID))
                .findFirst()
                .orElse(null);
    }
private void showCustomerDialog(Customer customer, DefaultTableModel model) {
    JTextField nameField = new JTextField();
    JTextField passwordField = new JTextField();
    JTextField phoneField = new JTextField();
    JTextField emailField = new JTextField();
    JTextField addressField = new JTextField();
    JTextField carPlateField = new JTextField();
    
    JRadioButton maleRadio = new JRadioButton("Male");
    JRadioButton femaleRadio = new JRadioButton("Female");
    ButtonGroup genderGroup = new ButtonGroup();
    genderGroup.add(maleRadio);
    genderGroup.add(femaleRadio);
    maleRadio.setSelected(true);

    boolean isEditMode = (customer != null);
    
    if (isEditMode) {
        nameField.setText(customer.getName());
        passwordField.setText(customer.getPassword());
        phoneField.setText(customer.getPhoneNo());
        emailField.setText(customer.getEmail());
        addressField.setText(customer.getAddress());
        if (customer.getCar() != null) {
            carPlateField.setText(customer.getCar().getPlateno());
        }
        if ("Female".equalsIgnoreCase(customer.getGender())) {
            femaleRadio.setSelected(true);
        } else {
            maleRadio.setSelected(true);
        }
        carPlateField.setEditable(false); 
        nameField.setEditable(false); 
        maleRadio.setEnabled(false);
        femaleRadio.setEnabled(false);
    }

    JPanel formPanel = new JPanel(new GridLayout(0, 1, 4, 4));
    formPanel.add(new JLabel("Name:"));
    formPanel.add(nameField);
    formPanel.add(new JLabel("Password:"));
    formPanel.add(passwordField);
    formPanel.add(new JLabel("Phone Number:"));
    formPanel.add(phoneField);
    formPanel.add(new JLabel("Email:"));
    formPanel.add(emailField);
    formPanel.add(new JLabel("Address:"));
    formPanel.add(addressField);
    formPanel.add(new JLabel("Car Plate:"));
    formPanel.add(carPlateField);
    formPanel.add(new JLabel("Gender:"));
    
    JPanel radioWrapper = new JPanel(new FlowLayout(FlowLayout.LEFT, 0, 0));
    radioWrapper.add(maleRadio);
    radioWrapper.add(femaleRadio);
    formPanel.add(radioWrapper);

    while (true) {
        int choice = JOptionPane.showConfirmDialog(this, formPanel,
                isEditMode ? "Edit Customer" : "Create Customer",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                
        if (choice != JOptionPane.OK_OPTION) return;

        String name = nameField.getText().trim();
        String password = passwordField.getText().trim();
        String phone = phoneField.getText().trim();
        String email = emailField.getText().trim();
        String address = addressField.getText().trim();
        String carPlate = carPlateField.getText().trim().toUpperCase();
        String gender = maleRadio.isSelected() ? "Male" : "Female";

        String validationError = validateCustomerInput(name, password, phone, email, address, carPlate, gender, 
                                                       isEditMode ? customer.getCustID() : null, !isEditMode);
        if (validationError != null) {
            JOptionPane.showMessageDialog(this, validationError, "Invalid Input", JOptionPane.ERROR_MESSAGE);
            continue;
        }

        if (!isEditMode) {
            Customer newCustomer = new Customer(name, password, phone, email, gender, address, null);
            Car car = new Car(carPlate, "", "", 0.0, 0, 0, newCustomer);
            newCustomer.setCar(car);
            FileHandler.allCust.add(newCustomer);
        } else {
            // STRATEGY: Update the live element inside FileHandler's master list directly
            for (Customer activeCust : FileHandler.allCust) {
                if (activeCust.getCustID().equals(customer.getCustID())) {
                    activeCust.setPassword(password);
                    activeCust.setPhoneNo(phone);
                    activeCust.setEmail(email);
                    activeCust.setAddress(address);
                    break;
                }
            }
        }

        // Save modifications to database file, reload completely, then draw fresh rows
        FileHandler.saveCustomerDtToFile();
        FileHandler.loadCustFromFile();
        refreshCustomerTable(model); 
        
        JOptionPane.showMessageDialog(this, 
                isEditMode ? "Customer updated successfully!" : "Customer created successfully!", 
                "Success", JOptionPane.INFORMATION_MESSAGE);
        break;
    }
}

    private String validateCustomerInput(String name, String password, String phone, String email, String address, String carPlate, String gender, String editingCustomerId, boolean creating) {
        if (name == null || name.trim().isEmpty()) return "Name is required.";
        if (!StartPage.isValidName(name)) return "Name must contain only letters, up to 30 characters.";
        FileHandler.loadCustFromFile();
        if (FileHandler.isActiveCustomerNameTaken(name, editingCustomerId)) return "This customer name is already used by an existing customer.";
        if (password.length() < 8) return "Password must be between 8 and 16 characters.";
        if (password.length() > 16) return "Password must be between 8 and 16 characters.";
        if (!phone.matches("[0-9]{10,11}")) return "Phone number must be 10 to 11 digits.";
        if (!email.matches("^[a-zA-Z0-9._%+-]+@gmail\\.com$")) return "Please enter a valid email address ending with @gmail.com.";
        if (address == null || address.trim().isEmpty()) return "Address is required.";
        if (!address.matches("^[A-Za-z0-9\\s,./-]{5,100}$")) return "Address can only contain letters, numbers, spaces, , / - . (5-100 characters).";
        if (creating) {
            if (carPlate == null || carPlate.trim().isEmpty()) return "Car plate is required.";
            if (!carPlate.matches("^(?=.*[A-Z])(?=.*\\d)[A-Z0-9]{2,13}$")) return "Car plate must be 2-13 characters long, contain letters and digits, and include at least one of each.";
            if (FileHandler.isCarPlateTaken(carPlate)) return "This car plate is already assigned to another customer.";
        }
        if (gender == null || gender.isEmpty()) return "Gender is required. Please select Male or Female.";
        if (!gender.equals("Male") && !gender.equals("Female")) return "Gender must be Male or Female.";
        return null;
    }

    private boolean isValidCarPlate(String plate) {
        return plate.matches("^[A-Za-z0-9]+$");
    }

    private String validateAppointmentInput(String plate, String serviceType, Date selectedDate, Date selectedTime) {
        if (plate == null || plate.trim().isEmpty()) return "Car plate is required.";
        if (!isValidCarPlate(plate.trim())) return "Car plate may only contain letters, numbers, spaces, and hyphens, up to 10 characters.";
        if (serviceType == null || !(serviceType.equals("Normal")
                || serviceType.equals("Major")
                || serviceType.equals("GeneralRepair")
                || serviceType.equals("Inspection"))) {
            return "Please select a valid service type.";
        }
        if (selectedDate == null) return "Appointment date is required.";
        if (selectedTime == null) return "Appointment time is required.";
        try {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
            SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm");
            String appointmentDateTime = dateFormat.format(selectedDate) + " " + timeFormat.format(selectedTime);
            if (appointmentDateTime.trim().isEmpty()) return "Appointment date and time are required.";
            Date appointment = new SimpleDateFormat("yyyy-MM-dd HH:mm").parse(appointmentDateTime);
            if (appointment.before(new Date())) return "Appointment must be scheduled for the future.";
        } catch (Exception ex) {
            return "Invalid appointment date or time format.";
        }
        return null;
    }

    private void handleSearch(JTextField searchField, JComboBox<String> searchCriteria) {
        String query = searchField.getText().trim().toLowerCase();
        String criteria = (String) searchCriteria.getSelectedItem();
        tableModel.setRowCount(0);
        FileHandler.loadServiceHistories();
        FileHandler.loadCustFromFile();

        for (ServiceHistories sh : FileHandler.allServiceHistories) {
            boolean matches = false;
            String historyCustomerName = sh.getCustomerName();
            Customer customer = FileHandler.allCust.stream()
                    .filter(c -> c.getName().equalsIgnoreCase(historyCustomerName)
                            || (c.getCar() != null && c.getCar().getPlateno().equalsIgnoreCase(sh.getCarPlate())))
                    .findFirst().orElse(null);

            switch (criteria) {
                case "Name":
                    if (!historyCustomerName.isEmpty()) {
                        matches = historyCustomerName.toLowerCase().contains(query);
                    } else if (customer != null) {
                        matches = customer.getName().toLowerCase().contains(query);
                    }
                    break;
                case "Phone":
                    if (customer != null) {
                        matches = customer.getPhoneNo().contains(query);
                    }
                    break;
                case "Car Plate":
                    matches = sh.getCarPlate().toLowerCase().contains(query);
                    break;
            }

            if (matches || query.isEmpty()) {
                tableModel.addRow(new Object[]{
                        sh.getServiceId(),
                        sh.getDate(),
                        sh.getCarPlate(),
                        sh.getTechnicianId(),
                        sh.getServiceType(),
                        sh.getStatus(),
                        sh.getPaymentStatus()
                });
            }
        }
    }

    private void handleViewServiceHistory() {
        int row = appointmentTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select an appointment to view service history.", "View Service History", JOptionPane.WARNING_MESSAGE);
            return;
        }

        String serviceId = (String) tableModel.getValueAt(row, 0);
        FileHandler.loadServiceHistories();
        ServiceHistories sh = FileHandler.allServiceHistories.stream()
                .filter(item -> item.getServiceId().equals(serviceId))
                .findFirst().orElse(null);

        if (sh == null) {
            JOptionPane.showMessageDialog(this, "Unable to locate the selected appointment.", "View Service History", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String historyCustomerName = sh.getCustomerName() != null ? sh.getCustomerName().trim() : "";
        String targetPlate = sh.getCarPlate() != null ? sh.getCarPlate().trim().toUpperCase() : "";

        // Display service history for this customer
        StringBuilder history = new StringBuilder();
        history.append("Service History for ").append(historyCustomerName.isEmpty() ? "(Deleted/Unknown Customer)" : historyCustomerName).append("\n");
        history.append("Car Plate: ").append(targetPlate.isEmpty() ? "(Unknown)" : targetPlate).append("\n\n");

        boolean firstRecord = true;
        for (ServiceHistories hist : FileHandler.allServiceHistories) {
            String histPlate = hist.getCarPlate() != null ? hist.getCarPlate().trim().toUpperCase() : "";
            String histName = hist.getCustomerName() != null ? hist.getCustomerName().trim() : "";
            boolean match = (!targetPlate.isEmpty() && targetPlate.equalsIgnoreCase(histPlate))
                    || (!historyCustomerName.isEmpty() && historyCustomerName.equalsIgnoreCase(histName));
            if (match) {
                if (!firstRecord) {
                    history.append("----------\n");
                }
                firstRecord = false;
                history.append("Service ID: ").append(hist.getServiceId()).append("\n");
                history.append("Date: ").append(hist.getDate()).append("\n");
                history.append("Technician: ").append(hist.getTechnicianId()).append("\n");
                history.append("Service Type: ").append(hist.getServiceType()).append("\n");
                history.append("Status: ").append(hist.getStatus()).append("\n");
                history.append("Payment: ").append(hist.getPaymentStatus()).append("\n");
                history.append("Remarks: ").append(hist.getRemarks() != null && !hist.getRemarks().isEmpty() ? hist.getRemarks() : "None").append("\n");
                history.append("Customer Remarks: ").append(hist.getCustomerRemarks()).append("\n");
                history.append("Technical Notes: ").append(hist.getTechnicalNotes()).append("\n");
            }
        }

        JTextArea textArea = new JTextArea(history.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));

        JOptionPane.showMessageDialog(this, scrollPane, "Customer Service History", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showCustomerServiceHistory(Customer customer) {
        FileHandler.loadServiceHistories();

        StringBuilder history = new StringBuilder();
        history.append("Service History for ").append(customer.getName()).append("\n");
        String targetPlate = (customer.getCar() != null && customer.getCar().getPlateno() != null)
                ? customer.getCar().getPlateno().trim().toUpperCase()
                : "";
        if (!targetPlate.isEmpty()) history.append("Car Plate: ").append(targetPlate).append("\n");
        history.append("\n");

        boolean hasHistory = false;
        boolean firstRecord = true;
        for (ServiceHistories hist : FileHandler.allServiceHistories) {
            String histPlate = hist.getCarPlate() != null ? hist.getCarPlate().trim().toUpperCase() : "";
            String histName = hist.getCustomerName() != null ? hist.getCustomerName().trim() : "";
            boolean match = (!targetPlate.isEmpty() && targetPlate.equalsIgnoreCase(histPlate))
                    || (customer.getName() != null && customer.getName().equalsIgnoreCase(histName));
            if (match) {
                hasHistory = true;
                if (!firstRecord) {
                    history.append("----------\n");
                }
                firstRecord = false;
                history.append("Service ID: ").append(hist.getServiceId()).append("\n");
                history.append("Date: ").append(hist.getDate()).append("\n");
                history.append("Technician: ").append(hist.getTechnicianId()).append("\n");
                history.append("Service Type: ").append(hist.getServiceType()).append("\n");
                history.append("Status: ").append(hist.getStatus()).append("\n");
                history.append("Payment: ").append(hist.getPaymentStatus()).append("\n");
                history.append("Remarks: ").append(hist.getRemarks() != null && !hist.getRemarks().isEmpty() ? hist.getRemarks() : "None").append("\n");
                history.append("Customer Remarks: ").append(hist.getCustomerRemarks()).append("\n");
                history.append("Technical Notes: ").append(hist.getTechnicalNotes()).append("\n");
            }
        }

        if (!hasHistory) {
            history.append("No service history found for this customer.");
        }

        JTextArea textArea = new JTextArea(history.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 400));

        JOptionPane.showMessageDialog(this, scrollPane, "Customer Service History", JOptionPane.INFORMATION_MESSAGE);
    }
}
