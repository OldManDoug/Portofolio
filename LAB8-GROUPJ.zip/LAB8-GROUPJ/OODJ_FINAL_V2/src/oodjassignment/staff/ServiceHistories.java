package oodjassignment.staff;

public class ServiceHistories {
    private String serviceId;
    private String date;
    private String endDate;
    private String carPlate; //needs to be from car
    private String customerName; //to relate back to customer
    private String technicianId;
    private String serviceType;
    private String status;
    private String paymentStatus; // maybe from counterstaff
    private String remarks;
    private String customerRemarks; //from customer's comments
    private String technicalNotes; //for feedback
    
    public ServiceHistories(String serviceId, String date, String endDate, String carPlate, 
                        String technicianId, String serviceType, 
                        String status, String paymentStatus, String remarks) {
        this(serviceId, date, endDate, carPlate, "", technicianId, serviceType, status, paymentStatus, remarks, "", "");
    }

    public ServiceHistories(String serviceId, String date, String endDate, String carPlate, 
                        String customerName,
                        String technicianId, String serviceType, 
                        String status, String paymentStatus, String remarks) {
        this(serviceId, date, endDate, carPlate, customerName, technicianId, serviceType, status, paymentStatus, remarks, "", "");
    }

    public ServiceHistories(String serviceId, String date, String endDate, String carPlate, 
                        String customerName,
                        String technicianId, String serviceType, 
                        String status, String paymentStatus, String remarks, String customerRemarks) {
        this(serviceId, date, endDate, carPlate, customerName, technicianId, serviceType, status, paymentStatus, remarks, customerRemarks, "");
    }

    public ServiceHistories(String serviceId, String date, String endDate, String carPlate, 
                        String customerName,
                        String technicianId, String serviceType, 
                        String status, String paymentStatus, String remarks, String customerRemarks, String technicalNotes) {
        this.serviceId = serviceId;
        this.date = date;
        this.endDate = endDate;
        this.carPlate = carPlate;
        this.customerName = customerName;
        this.technicianId = technicianId;
        this.serviceType = serviceType;
        this.status = status;
        this.paymentStatus = paymentStatus;
        this.remarks = remarks;
        this.customerRemarks = customerRemarks;
        this.technicalNotes = technicalNotes;
    }

    //Getters
    public String getServiceId() { return serviceId; }
    public String getDate() { return date; }
    public String getEndDate() { return endDate; }
    public String getCarPlate() { return carPlate; }
    public String getTechnicianId() { return technicianId; }
    public String getServiceType() { return serviceType; }
    public String getStatus() { return status; }
    public String getPaymentStatus() { return paymentStatus; }
    public String getRemarks() { return remarks; }
    public String getCustomerName() { return customerName == null ? "" : customerName; }
    
    //Setters
    public void setStatus(String status) { this.status = status; }
    public void setPaymentStatus(String paymentStatus) { this.paymentStatus = paymentStatus; }
    public String getCustomerRemarks() {
        return (customerRemarks == null || customerRemarks.isEmpty()) ? "No remarks" : customerRemarks;
    }

    public void setCustomerRemarks(String customerRemarks) {
        this.customerRemarks = customerRemarks;
    }

    public String getTechnicalNotes() {
        return (technicalNotes == null || technicalNotes.isEmpty()) ? "No technical notes yet" : technicalNotes;
    }

    public void setTechnicalNotes(String technicalNotes) {
        this.technicalNotes = technicalNotes;
    }
}

