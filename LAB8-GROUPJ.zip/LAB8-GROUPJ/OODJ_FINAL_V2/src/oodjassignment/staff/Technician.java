package oodjassignment.staff;

public class Technician extends Staff {
    public Technician(String id, String name, String password) {
        super(id, name, password, "Technician");
    }
}