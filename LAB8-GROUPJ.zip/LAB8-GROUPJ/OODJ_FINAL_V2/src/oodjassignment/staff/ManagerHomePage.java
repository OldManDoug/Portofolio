package oodjassignment.staff;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.io.File;
import java.util.Scanner;
import java.util.ArrayList;
import oodjassignment.FileHandler;
import oodjassignment.Car;
import oodjassignment.Customer;
import oodjassignment.StartPage;
import oodjassignment.CustomerServiceHistory; // Make sure this is imported

public class ManagerHomePage extends JFrame {
    private JTable displayTable;
    private DefaultTableModel tableModel;
    private boolean showingStaff = true;
    private Manager currentManager;

    // UI Colors
    private final Color PRIMARY_COLOR = new Color(44, 62, 80);
    private final Color ACCENT_COLOR = new Color(52, 152, 219);
    private final Color BG_COLOR = new Color(236, 240, 241);

    public ManagerHomePage(Manager manager) {
        this.currentManager = manager;

        setTitle("Manager Dashboard - " + manager.getName());
        setSize(1100, 650);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        getContentPane().setBackground(BG_COLOR);
        setLayout(new BorderLayout(10, 10));

        // --- Header ---
        JPanel header = new JPanel();
        header.setBackground(PRIMARY_COLOR);
        JLabel lblHeader = new JLabel("Workshop Management System | Welcome, " + manager.getName());
        lblHeader.setForeground(Color.WHITE);
        lblHeader.setFont(new Font("Segoe UI", Font.BOLD, 22));
        header.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        header.add(lblHeader);
        add(header, BorderLayout.NORTH);

        // --- Table ---
        tableModel = new DefaultTableModel();
        displayTable = new JTable(tableModel);
        styleTable();
        loadStaffTable();
        
        JScrollPane scrollPane = new JScrollPane(displayTable);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 20));
        add(scrollPane, BorderLayout.CENTER);

        // --- Control Panel ---
        JPanel bottomContainer = new JPanel(new GridLayout(2, 1, 5, 5));
        bottomContainer.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        bottomContainer.setOpaque(false);

        JPanel filterRow = new JPanel(new FlowLayout(FlowLayout.LEFT));
        filterRow.setOpaque(false);
        JButton btnToggleView = createStyledButton("Switch to Customer List", ACCENT_COLOR);
        String[] filterOptions = {"Show All", "Manager", "Technician", "Counter Staff"};
        JComboBox<String> roleFilter = new JComboBox<>(filterOptions);
        
        filterRow.add(new JLabel("View Mode: "));
        filterRow.add(btnToggleView);
        filterRow.add(new JLabel("   |   Filter: "));
        filterRow.add(roleFilter);

        JPanel actionRow = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 0));
        actionRow.setOpaque(false);
        JButton btnAdd = createStyledButton("Register New", new Color(39, 174, 96));
        JButton btnModify = createStyledButton("Modify", ACCENT_COLOR);
        JButton btnDelete = createStyledButton("Delete", new Color(231, 76, 60));
        JButton btnReport = createStyledButton("Revenue Report", PRIMARY_COLOR);
        JButton btnFeedback = createStyledButton("Feedback", PRIMARY_COLOR);
        JButton btnSetPrice = createStyledButton("Set Prices", PRIMARY_COLOR);
        JButton btnLogout = createStyledButton("Logout", new Color(149, 165, 166));

        actionRow.add(btnAdd); actionRow.add(btnModify); actionRow.add(btnDelete);
        actionRow.add(btnSetPrice); actionRow.add(btnReport);
        actionRow.add(btnFeedback); actionRow.add(btnLogout);

        bottomContainer.add(filterRow);
        bottomContainer.add(actionRow);
        add(bottomContainer, BorderLayout.SOUTH);

        // --- Logic & Listeners ---
        btnToggleView.addActionListener(e -> {
            showingStaff = !showingStaff;
            btnToggleView.setText(showingStaff ? "Switch to Customer List" : "Switch to Staff List");
            roleFilter.setEnabled(showingStaff);
            if(showingStaff) loadStaffTable(); else loadCustomerTable();
        });

        roleFilter.addActionListener(e -> { if(showingStaff) loadFilteredStaffData((String) roleFilter.getSelectedItem()); });
        btnAdd.addActionListener(e -> { if(showingStaff) handleRegisterStaff(); else JOptionPane.showMessageDialog(this, "Customer registration is handled on the Registration Page."); });
        btnModify.addActionListener(e -> handleModify());
        btnDelete.addActionListener(e -> handleDelete());
        btnReport.addActionListener(e -> handleReport());
        btnFeedback.addActionListener(e -> handleViewFeedback());
        btnSetPrice.addActionListener(e -> handleSetPrice());
        btnLogout.addActionListener(e -> { this.dispose(); new oodjassignment.StartPage().setVisible(true); });
    }

    private void styleTable() {
        displayTable.setRowHeight(35);
        displayTable.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        JTableHeader header = displayTable.getTableHeader();
        header.setBackground(PRIMARY_COLOR);
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
    }

    private JButton createStyledButton(String text, Color bg) {
        JButton btn = new JButton(text);
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btn.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));
        return btn;
    }

    // --- HELPER METHODS ---
    
    private void handleSetPrice() {
        String pNormal = "50.00", pMajor = "100.00", pRepair = "25.00", pInspect = "30.00";

        try (Scanner s = new Scanner(new File("prices.txt"))) {
            while (s.hasNextLine()) {
                String line = s.nextLine().trim();
                if (line.isEmpty()) continue;
                String[] p = line.split(",");
                if (p.length >= 2) {
                    if (p[0].equals("NormalService")) pNormal = p[1];
                    else if (p[0].equals("MajorService")) pMajor = p[1];
                    else if (p[0].equals("GeneralRepair")) pRepair = p[1];
                    else if (p[0].equals("InspectionFee")) pInspect = p[1];
                }
            }
        } catch (Exception e) {
            // File not found defaults used gracefully
        }

        JTextField normalF = new JTextField(pNormal);
        JTextField majorF = new JTextField(pMajor);
        JTextField repairF = new JTextField(pRepair);
        JTextField inspectionF = new JTextField(pInspect);

        Object[] message = {
            "Normal Service (RM):", normalF,
            "Major Service (RM):", majorF,
            "General Repair (RM):", repairF,
            "Inspection Fee (RM):", inspectionF
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Update Service Price Menu", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            FileHandler.saveAllPrices(
                normalF.getText().trim(), 
                majorF.getText().trim(), 
                repairF.getText().trim(), 
                inspectionF.getText().trim()
            );
            JOptionPane.showMessageDialog(this, "Service Menu Updated!");
        }
    }

    private void loadStaffTable() {
        tableModel.setRowCount(0);
        tableModel.setColumnIdentifiers(new String[]{"Staff ID", "Name", "Password", "Role"});
        FileHandler.loadStaffFromFile();
        for (Staff s : FileHandler.allStaff) {
            tableModel.addRow(new Object[]{s.getId(), s.getName(), s.getPassword(), s.getRole()});
        }
    }

    private void loadCustomerTable() {
        tableModel.setRowCount(0);
        tableModel.setColumnIdentifiers(new String[]{"Customer ID", "Name", "Email", "Phone", "Car Plate", "Address"});
        FileHandler.loadCustFromFile(); 
        for (Customer c : FileHandler.allCust) {
            tableModel.addRow(new Object[]{
                c.getCustID(),
                c.getName(),
                c.getEmail(),
                c.getPhoneNo(),
                c.getCar() != null ? c.getCar().getPlateno() : "",
                c.getAddress()
            });
        }
    }

    private void loadFilteredStaffData(String filter) {
        tableModel.setRowCount(0);
        for (Staff s : FileHandler.allStaff) {
            if (filter.equals("Show All") || s.getRole().equalsIgnoreCase(filter)) {
                tableModel.addRow(new Object[]{s.getId(), s.getName(), s.getPassword(), s.getRole()});
            }
        }
    }

    private void handleModify() {
        int row = displayTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row first!");
            return;
        }

        String currentId = (String) tableModel.getValueAt(row, 0);
        
        if (showingStaff) {
            for (Staff s : FileHandler.allStaff) {
                if (s.getId().equals(currentId)) {
                    JTextField idField = new JTextField(s.getId());
                    JTextField nameField = new JTextField(s.getName());
                    JTextField passField = new JTextField(s.getPassword());

                    Object[] message = {
                        "Edit Staff ID:", idField,
                        "Edit Name:", nameField,
                        "Edit Password:", passField
                    };

                    int option = JOptionPane.showConfirmDialog(this, message, "Modify Staff", JOptionPane.OK_CANCEL_OPTION);
                    if (option == JOptionPane.OK_OPTION) {
                        s.setId(idField.getText());
                        s.setName(nameField.getText());
                        s.setPassword(passField.getText());
                        
                        FileHandler.saveStaffToFile();
                        loadStaffTable();
                        JOptionPane.showMessageDialog(this, "Staff Updated!");
                    }
                    break;
                }
            }
        } else {
            for (Customer c : FileHandler.allCust) {
                if (c.getCustID().equals(currentId)) {
                    JLabel nameLabel = new JLabel(c.getName());
                    JTextField passwordField = new JTextField(c.getPassword());
                    JTextField emailField = new JTextField(c.getEmail());
                    JTextField phoneField = new JTextField(c.getPhoneNo());
                    JTextField addressField = new JTextField(c.getAddress());
                    JTextField carPlateField = new JTextField(c.getCar() != null ? c.getCar().getPlateno() : "");
                    carPlateField.setEditable(false); // public key; no edits allowed
                    JLabel genderLabel = new JLabel(c.getGender() != null ? c.getGender() : "");

                    while (true) {
                        Object[] message = { 
                            "Name:", nameLabel, 
                            "Password:", passwordField,
                            "Email:", emailField, 
                            "Phone:", phoneField,
                            "Address:", addressField,
                            "Car Plate:", carPlateField,
                            "Gender:", genderLabel
                        };
                        
                        int option = JOptionPane.showConfirmDialog(this, message, "Modify Customer", JOptionPane.OK_CANCEL_OPTION);
                        if (option != JOptionPane.OK_OPTION) {
                            break;
                        }

                        String password = passwordField.getText().trim();
                        String email = emailField.getText().trim();
                        String phone = phoneField.getText().trim();
                        String address = addressField.getText().trim();

                        if (!StartPage.validatePassword(password)) {
                            JOptionPane.showMessageDialog(this, "Password must be between 8 and 16 characters.", "Error", JOptionPane.ERROR_MESSAGE);
                            continue;
                        }
                        if (!StartPage.validateEmail(email)) {
                            JOptionPane.showMessageDialog(this, "Please enter a valid email address ending with @gmail.com.", "Error", JOptionPane.ERROR_MESSAGE);
                            continue;
                        }
                        if (!StartPage.validatePhoneNo(phone)) {
                            JOptionPane.showMessageDialog(this, "Phone number must be 10 to 11 digits.", "Error", JOptionPane.ERROR_MESSAGE);
                            continue;
                        }
                        if (!StartPage.validateAddress(address)) {
                            JOptionPane.showMessageDialog(this, "Address can only contain letters, numbers, spaces, , / - . (5-100 characters).", "Error", JOptionPane.ERROR_MESSAGE);
                            continue;
                        }

                        c.setPassword(password);
                        c.setEmail(email);
                        c.setPhoneNo(phone);
                        c.setAddress(address);
                        // Car plate is the public key; do not change it on edit.
                        
                        FileHandler.saveCustomerDtToFile(); 
                        loadCustomerTable();
                        JOptionPane.showMessageDialog(this, "Customer data updated successfully!");
                        break;
                    }
                    break;
                }
            }
        }
    }
        
    private void handleDelete() {
        int row = displayTable.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row first!");
            return;
        }

        String id = (String) tableModel.getValueAt(row, 0);
        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete ID: " + id + "?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        
        if (confirm == JOptionPane.YES_OPTION) {
            if (showingStaff) {
                FileHandler.allStaff.removeIf(s -> s.getId().equals(id));
                FileHandler.saveStaffToFile();
                loadStaffTable();
            } else {
                Customer toDelete = null;
                for (Customer c : FileHandler.allCust) {
                    if (c != null && c.getCustID() != null && c.getCustID().equals(id)) {
                        toDelete = c;
                        break;
                    }
                }
                if (toDelete != null) {
                    FileHandler.archiveDeletedCustomer(toDelete, currentManager != null ? currentManager.getName() : "Manager");
                }
                FileHandler.allCust.removeIf(c -> c != null && id.equals(c.getCustID()));
                FileHandler.saveCustomerDtToFile();
                loadCustomerTable();
            }
        }
    }

    private void handleReport() {
        int normalCount = 0, majorCount = 0, repairCount = 0, inspectCount = 0;
        int pendingNormal = 0, pendingMajor = 0, pendingRepair = 0, pendingInspect = 0;
        
        double pNormal = 50.0, pMajor = 100.0, pRepair = 25.0, pInspect = 30.0;

        try (Scanner s = new Scanner(new File("prices.txt"))) {
            while (s.hasNextLine()) {
                String line = s.nextLine().trim();
                if (line.isEmpty()) continue;
                String[] p = line.split(",");
                if (p.length >= 2) {
                    if (p[0].equals("NormalService")) pNormal = Double.parseDouble(p[1]);
                    else if (p[0].equals("MajorService")) pMajor = Double.parseDouble(p[1]);
                    else if (p[0].equals("GeneralRepair")) pRepair = Double.parseDouble(p[1]);
                    else if (p[0].equals("InspectionFee")) pInspect = Double.parseDouble(p[1]);
                }
            }
        } catch (Exception e) { 
            // Fallback default prices remain unchanged
        }

        FileHandler.loadServiceHistories(); 
        for (ServiceHistories sh : FileHandler.allServiceHistories) {
            String type = sh.getServiceType();
            String paymentStatus = sh.getPaymentStatus();
            
            if (type != null && paymentStatus != null) {
                type = type.trim();
                paymentStatus = paymentStatus.trim();

                // FIXED INTERACTION RULES: Strings match short names explicitly
                if (paymentStatus.equalsIgnoreCase("Paid")) {
                    if (type.equalsIgnoreCase("Normal") || type.equalsIgnoreCase("Normal Service")) normalCount++;
                    else if (type.equalsIgnoreCase("Major") || type.equalsIgnoreCase("Major Service")) majorCount++;
                    else if (type.equalsIgnoreCase("General Repair")) repairCount++;
                    else if (type.equalsIgnoreCase("Inspection Fee") || type.equalsIgnoreCase("Inspection")) inspectCount++;
                } else if (paymentStatus.equalsIgnoreCase("Pending")) {
                    if (type.equalsIgnoreCase("Normal") || type.equalsIgnoreCase("Normal Service")) pendingNormal++;
                    else if (type.equalsIgnoreCase("Major") || type.equalsIgnoreCase("Major Service")) pendingMajor++;
                    else if (type.equalsIgnoreCase("General Repair")) pendingRepair++;
                    else if (type.equalsIgnoreCase("Inspection Fee") || type.equalsIgnoreCase("Inspection")) pendingInspect++;
                }
            }
        }

        double totalPaidRevenue = (normalCount * pNormal) + (majorCount * pMajor) + 
                                  (repairCount * pRepair) + (inspectCount * pInspect);
                                 
        double totalPendingRevenue = (pendingNormal * pNormal) + (pendingMajor * pMajor) + 
                                     (pendingRepair * pRepair) + (pendingInspect * pInspect);

        String report = String.format(
            "=========================================\n" +
            "        APU-ASC FINANCIAL REVENUE REPORT \n" +
            "=========================================\n\n" +
            "--- RECEIVED REVENUE (Status: Paid) ---\n" +
            "Normal Service: %d jobs @ RM%.2f\n" +
            "Major Service:  %d jobs @ RM%.2f\n" +
            "General Repair: %d jobs @ RM%.2f\n" +
            "Inspection Fee: %d jobs @ RM%.2f\n" + 
            "-----------------------------------------\n" +
            "ACTUAL REVENUE COLLECTED:  RM%.2f\n\n" +
            "--- UNPAID REVENUE (Status: Pending) ---\n" +
            "Normal Service: %d jobs pending\n" +
            "Major Service:  %d jobs pending\n" +
            "General Repair: %d jobs pending\n" +
            "Inspection Fee: %d jobs pending\n" +
            "-----------------------------------------\n" +
            "POTENTIAL REVENUE OUTSTANDING: RM%.2f\n\n" +
            "=========================================\n" +
            "COMBINED TOTAL EXPECTED:   RM%.2f\n" +
            "=========================================",
            normalCount, pNormal, majorCount, pMajor, repairCount, pRepair, inspectCount, pInspect, totalPaidRevenue,
            pendingNormal, pendingMajor, pendingRepair, pendingInspect, totalPendingRevenue,
            (totalPaidRevenue + totalPendingRevenue)
        );

        JTextArea txtReport = new JTextArea(report);
        txtReport.setFont(new Font("Monospaced", Font.PLAIN, 12));
        txtReport.setEditable(false);
        
        JOptionPane.showMessageDialog(this, new JScrollPane(txtReport), "Manager Revenue Report", JOptionPane.INFORMATION_MESSAGE);
    }

    private void handleViewFeedback() {
        FileHandler.loadFeedbackFromFile();
        
        JDialog dialog = new JDialog(this, "Feedback Manager", true);
        dialog.setSize(600, 400);
        dialog.setLayout(new BorderLayout());

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        
        String[] options = {"Customer Feedback", "Technician Solutions"};
        JComboBox<String> filter = new JComboBox<>(options);

        filter.addActionListener(e -> {
            StringBuilder sb = new StringBuilder();
            String selected = (String) filter.getSelectedItem();
            
            for (String fb : FileHandler.allFeedback) {
                boolean isTech = fb.contains("FINAL SOLUTION") || fb.contains("Service ID: SH");
                
                if (selected.equals("Technician Solutions") && isTech) {
                    sb.append(fb).append("\n------------------\n");
                } else if (selected.equals("Customer Feedback") && !isTech) {
                    sb.append(fb).append("\n------------------\n");
                }
            }
            textArea.setText(sb.toString());
        });

        filter.setSelectedIndex(0); 
        
        JPanel topPanel = new JPanel();
        topPanel.add(new JLabel("Select Category:"));
        topPanel.add(filter);
        
        dialog.add(topPanel, BorderLayout.NORTH);
        dialog.add(new JScrollPane(textArea), BorderLayout.CENTER);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    private void handleRegisterStaff() {
        JTextField nameF = new JTextField();
        JTextField passF = new JTextField();
        String[] roles = {"Technician", "Counter Staff", "Manager"};
        JComboBox<String> roleBox = new JComboBox<>(roles);

        Object[] message = { "Name:", nameF, "Password:", passF, "Role:", roleBox };
        int option = JOptionPane.showConfirmDialog(this, message, "Add New Staff", JOptionPane.OK_CANCEL_OPTION);
        
        if (option == JOptionPane.OK_OPTION) {
            String role = (String) roleBox.getSelectedItem();
            String prefix = role.equals("Manager") ? "M" : (role.equals("Technician") ? "T" : "S");
            
            int max = 0;
            for (Staff s : FileHandler.allStaff) {
                if (s.getId().startsWith(prefix)) {
                    try {
                        int num = Integer.parseInt(s.getId().substring(1));
                        if (num > max) max = num;
                    } catch (Exception e) {}
                }
            }
            String id = String.format("%s%03d", prefix, max + 1);

            if (role.equals("Manager")) FileHandler.allStaff.add(new Manager(id, nameF.getText(), passF.getText()));
            else if (role.equals("Technician")) FileHandler.allStaff.add(new Technician(id, nameF.getText(), passF.getText()));
            else FileHandler.allStaff.add(new Staff(id, nameF.getText(), passF.getText(), "Counter Staff"));

            FileHandler.saveStaffToFile();
            loadStaffTable();
        }
    }
}