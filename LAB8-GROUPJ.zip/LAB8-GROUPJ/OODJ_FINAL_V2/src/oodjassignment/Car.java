package oodjassignment;

import java.util.ArrayList;

public class Car {

   
//    public Car() {
//    }     
    protected String plateno;
    private String model;
    private String color;
    private double cc;
    private int mileage;
    private int mfgyr;
    private boolean tax;
    
    //Technician tech;
    Customer cust; //relationship with name of customer
    private static ArrayList<CustomerServiceHistory> allHistory = new ArrayList<CustomerServiceHistory>();
    // each Car has its own service record ? 
    
    public Car(){
        this("","","",0.00,0,0,null);
    } // no arg
    //arg cons
    public Car(String plateno,String model, String color, double cc,int mileage,int mfgyr, Customer cust) {
        this.plateno = plateno;
        this.model = model;
        this.color = color;
        this.cc = cc;
        this.mileage = mileage;   
        this.mfgyr = mfgyr;
        this.cust = cust;
    }    

    public String getPlateno() {
        return plateno;
    }

    public void setPlateno(String plateno) {
        this.plateno = plateno;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public double getCc() {
        return cc;
    }

    public int getMileage() {
        return mileage;
    }

    public void setMileage(int mileage) {
        this.mileage = mileage;
    }

    public void setCc(double cc) {
        this.cc = cc;
    }

    public String getCust() {
         return cust.getName(); // you need the name of owner. 
        // return cust.getEmail(); //subsitute? return cust why 2 cannot 
    }
    public String getCust1(){
       return cust.getPhoneNo();
    }

    public void setCust(Customer cust) {
        this.cust = cust;
    }

    public static ArrayList<CustomerServiceHistory> getAllHistory() {
        return allHistory;
    }

    public static void setAllHistory(ArrayList<CustomerServiceHistory> allHistory) {
        Car.allHistory = allHistory;
    }
     /**
     * @return the mfgyr
     */
    public int getMfgyr() {
        return mfgyr;
    }

    /**
     * @param mfgyr the mfgyr to set
     */
    public void setMfgyr(int mfgyr) {
        this.mfgyr = mfgyr;
    }

    /**
     * @return the tax
     */
    public boolean isTax() {
        return tax;
    }
    /**
     * @param tax the tax to set
     */
    public void setTax(boolean tax) {
        this.tax = tax;
    }
    
// this is only to get the  Customer relationship with Car
   /* public void setCust(Customer cust) {
        this.cust = cust;
    }?*/

    @Override //polymorphsm
    public String toString() {
        return "Car{" + "plateno=" + plateno + ", model=" + getModel() + ", mileage=" + getMileage() + ", tax=" + isTax() + ","
                + " Owner=" + cust.getName() +" House Address="+cust.getAddress()+ '}';
    }
    
}

