package oodjassignment;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.Scanner;
import java.text.SimpleDateFormat;
import java.util.Date;
import oodjassignment.staff.Staff;
import oodjassignment.staff.Manager;
import oodjassignment.staff.Technician;
import oodjassignment.staff.CounterStaff;
import oodjassignment.staff.ServiceHistories;

public class FileHandler {
    public static ArrayList<Customer> allCust = new ArrayList<Customer>();
    public static ArrayList<CustomerServiceHistory> allHistory = new ArrayList<CustomerServiceHistory>(); //one for this and that. 
    public static ArrayList<Car> allCars = new ArrayList<Car>();
    public static ArrayList<CustomerPaymentHistory> allPhistory = new ArrayList<CustomerPaymentHistory>();
    private static boolean pricesLoaded = false;
    private static double normalServicePrice = 50.0;
    private static double majorServicePrice = 100.0;
    private static double generalRepairPrice = 20.0;
    private static double inspectionFee = 30.0;
    //comments? 
    
    private static String escapeCsv(String value) {
        if (value == null) {
            return "";
        }
        String escaped = value.replace("\"", "\"\"");
        return "\"" + escaped + "\"";
    }

    private static String unescapeCsv(String value) {
        if (value == null) {
            return "";
        }
        String trimmed = value.trim();
        if (trimmed.length() >= 2 && trimmed.startsWith("\"") && trimmed.endsWith("\"")) {
            trimmed = trimmed.substring(1, trimmed.length() - 1).replace("\"\"", "\"");
        }
        return trimmed;
    }

    private static String[] parseCsvLine(String line) {
        String[] parts = line.split(",(?=(?:[^\"]*\"[^\"]*\")*$)", -1);
        for (int i = 0; i < parts.length; i++) {
            parts[i] = unescapeCsv(parts[i]);
        }
        return parts;
    }

    public static Customer firstCust = null; // Static variable to keep the first supplier
    private static Customer loggedInCust = null;  // Track the currently logged-in admin
    
    // Customer name is treated as unique among ACTIVE customers (customers.txt).
    // If a customer was deleted, their record is archived elsewhere and their name becomes reusable.
    public static boolean isActiveCustomerNameTaken(String name, String exceptCustomerId) {
        if (name == null) return false;
        String normalized = name.trim();
        if (normalized.isEmpty()) return false;

        for (Customer c : allCust) {
            if (c == null) continue;
            String existingName = c.getName();
            if (existingName == null) continue;
            if (!existingName.trim().equalsIgnoreCase(normalized)) continue;

            if (exceptCustomerId != null && c.getCustID() != null && c.getCustID().equals(exceptCustomerId)) {
                continue; // allow unchanged name for the same customer
            }
            return true;
        }
        return false;
    }

    // Archive soft-deleted customers so service histories remain auditable.
    public static void archiveDeletedCustomer(Customer c, String deletedBy) {
        if (c == null) return;
        String carPlate = "";
        String carModel = "";
        if (c.getCar() != null) {
            carPlate = c.getCar().getPlateno();
            carModel = c.getCar().getModel();
        }

        // Append format:
        // DeletedAt,DeletedBy,ID,Name,Password,Phone,Email,Gender,Address,CarPlate,CarModel
        String deletedAt = LocalDateTime.now().toString();
        String by = (deletedBy == null || deletedBy.trim().isEmpty()) ? "Unknown" : deletedBy.trim();
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("deleted_customers.txt", true))) {
            writer.write(escapeCsv(deletedAt) + "," +
                    escapeCsv(by) + "," +
                    escapeCsv(c.getCustID()) + "," +
                    escapeCsv(c.getName()) + "," +
                    escapeCsv(c.getPassword()) + "," +
                    escapeCsv(c.getPhoneNo()) + "," +
                    escapeCsv(c.getEmail()) + "," +
                    escapeCsv(c.getGender()) + "," +
                    escapeCsv(c.getAddress()) + "," +
                    escapeCsv(carPlate) + "," +
                    escapeCsv(carModel));
            writer.newLine();
        } catch (IOException e) {
            System.out.println("Error archiving deleted customer: " + e.getMessage());
        }
    }

    // Method to save all customers to a file
    public static void saveCustomerDtToFile() {
    try (BufferedWriter writer = new BufferedWriter(new FileWriter("customers.txt"))) {
        // Loop through ArrayList instead linked pointers
        for (Customer c : allCust) {
            if (c != null) {
                String carPlate = "";
                String carModel = "";
                if (c.getCar() != null) {
                    carPlate = c.getCar().getPlateno();
                    carModel = c.getCar().getModel();
                }
                // Format: ID,Name,Password,Phone,Email,Gender,Address,CarPlate,CarModel
                writer.write(escapeCsv(c.getCustID()) + "," + 
                             escapeCsv(c.getName()) + "," + 
                             escapeCsv(c.getPassword()) + "," + 
                             escapeCsv(c.getPhoneNo()) + "," + 
                             escapeCsv(c.getEmail()) + "," + 
                             escapeCsv(c.getGender()) + "," + 
                             escapeCsv(c.getAddress()) + "," + 
                             escapeCsv(carPlate) + "," + 
                             escapeCsv(carModel));
                writer.newLine();
            }
        }
        writer.write("ID_COUNTER=" + Customer.getIdCounter());
        writer.newLine();
    } catch (IOException e) {
        e.printStackTrace();
    }
}
        // Method to load all customers from a file
    public static void loadCustFromFile() {
    firstCust = null;
    allCust.clear();
    int maxCustomerNumber = 0;
    int fileNextCounter = 1;

    try (BufferedReader reader = new BufferedReader(new FileReader("customers.txt"))) {
        String line;
        Customer lastCust = null;

        while ((line = reader.readLine()) != null) {
            if (line.trim().isEmpty()) continue;

            if (line.startsWith("ID_COUNTER=")) {
                try {
                    fileNextCounter = Integer.parseInt(line.substring("ID_COUNTER=".length()));
                } catch (Exception e) {}
            } else {
                String[] parts = parseCsvLine(line);
                if (parts.length >= 7) {
                    String customerId = parts[0].trim();
                    String name = parts[1].trim();
                    String password = parts[2].trim();
                    String phone = parts[3].trim();
                    String email = parts[4].trim();
                    String gender = parts[5].trim();
                    String address = parts[6].trim();
                    String plate = parts.length > 7 ? parts[7].trim() : "";
                    String model = parts.length > 8 ? parts[8].trim() : "";
//these parts import from Car
                    Car car = null;
                    if (!plate.isEmpty() || !model.isEmpty()) {
                        car = new Car(plate, model, "", 0.0, 0, 0, null);
                    }

                    Customer newCust = new Customer(customerId, name, password, phone, email, gender, address, car);
                    if (car != null) {
                        car.setCust(newCust);
                    }
//to add a new customer by constructor calling
                    allCust.add(newCust);
                    if (firstCust == null) {
                        firstCust = newCust;
                        lastCust = newCust;
                    } else {
                        lastCust.setNextCust(newCust);
                        lastCust = newCust;
                    }

                    try {
                        String numeric = customerId.replaceAll("\\D", "");
                        if (!numeric.isEmpty()) {
                            maxCustomerNumber = Math.max(maxCustomerNumber, Integer.parseInt(numeric));
                        }
                    } catch (NumberFormatException e) {
                        // ignore invalid IDs
                    }
                }
            }
        }
    } catch (IOException e) {
        System.out.println("Error loading customers: " + e.getMessage());
    }

    int nextCustomerId = Math.max(fileNextCounter, maxCustomerNumber + 1);
    Customer.setIdCounter(nextCustomerId);
}
    
    public static String displayCustomer(Customer cust) { //ONE GUY
    if (cust == null) return "";

    StringBuilder sb = new StringBuilder();
    sb.append("ID: ").append(cust.getCustID())
      .append("\nName: ").append(cust.getName())
      .append("\nPhone: ").append(cust.getPhoneNo())
      .append("\nEmail: ").append(cust.getEmail())
      .append("\nGender: ").append(cust.getGender())
      .append("\nAddress: ").append(cust.getAddress())
      .append("\nCar: ").append(cust.toString()); //cust.getCar()
//password too, but make it hidden? 
    return sb.toString();
}

    // Method to display all  build customer details as string
public static String displayAllCustomers() {
    Customer currentCust = firstCust;
    StringBuilder sb = new StringBuilder();

    while (currentCust != null) {
        sb.append("ID: ").append(currentCust.getCustID())
          .append(", Name: ").append(currentCust.getName())
          .append(", Phone: ").append(currentCust.getPhoneNo())
          .append(", Email: ").append(currentCust.getEmail())
          .append(", Gender: ").append(currentCust.getGender())
          .append(", Address: ").append(currentCust.getAddress())
          .append(", Car: ").append(currentCust.toString1())
          .append("\n");

        currentCust = currentCust.getNextCust();
    }

    return sb.toString();
}

   
    public static Customer checkName(String s){
        for(Customer a : allCust){
            if(a.getName().equals((s))){
                return a;
            }
        }
        return null;
    }

    public static boolean isCarPlateTaken(String plate) {
        if (plate == null) return false;
        String normalized = plate.trim().toUpperCase();
        for (Customer c : allCust) {
            if (c.getCar() != null && normalized.equals(c.getCar().getPlateno())) {
                return true;
            }
        }
        return false;
    }

    //check the plate number of car
    public static Car checkCarPlateNo(String s){
        for(Car a : allCars){
            if(a.getPlateno().equals((s))){
                return a;
            }
        }
        return null;
    }
    //Custoemr
    public static CustomerServiceHistory checkUsername(String s){
        for(CustomerServiceHistory a : allHistory){
            if(a.getName().equals((s))){
                return a;
            }
        }
        return null;
    }
    //validates the year & mont
    public static CustomerServiceHistory checkYear(YearMonth y){
        for(CustomerServiceHistory a : allHistory){
            if(a.getYearMonth() == y){
                return a;
            }
        }
        return null;
    }
     public static void saveComment(String comment) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("comments.txt", true))) {
            writer.write(comment);
            writer.newLine();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    //to show payments- changeable it works just add values
    public static String displayPaymentsForCustomer(Customer cust) {
    StringBuilder sb = new StringBuilder();
    for (CustomerPaymentHistory ph : allPhistory) {
        if (ph.getPayee().equals(cust)) {   // only show this customer's payments
            sb.append("Payment No: ").append(ph.getNumber())
              .append(", Month: ").append(ph.getMonth())
              .append(", Payee: ").append(ph.getPayee().getName())
              .append(", Amount: ").append(ph.getAmount())
              .append(", Reciept reference: ").append(ph.getReceiptId())
              .append(", Service reference: ").append(ph.getServiceId())
              .append("\n");
        }
    }
    return sb.toString();
}
//display individual service history changeing
public static String displayServicesForCustomer(Customer cust) {
    loadServiceHistories(); // read from the latest file
    StringBuilder sb = new StringBuilder();
    boolean recordsFound = false;
    for (ServiceHistories sh : allServiceHistories) {  // change to use the service Histories only
        if (sh.getCustomerName().equalsIgnoreCase(cust.getName())) { //sh.getCarPlate().equals(cust)
            recordsFound = true;
            
            sb.append("-------------------------------------------\n");
            sb.append("Service ID      : ").append(sh.getServiceId()).append("\n");
            sb.append("Date Booked     : ").append(sh.getDate()).append("\n");
            if (!sh.getEndDate().isEmpty()) {
                sb.append("Date Completed  : ").append(sh.getEndDate()).append("\n");
            }
            sb.append("Car Plate       : ").append(sh.getCarPlate()).append("\n");
            sb.append("Service Type    : ").append(sh.getServiceType()).append("\n");
            sb.append("Status          : ").append(sh.getStatus()).append("\n");
            sb.append("Payment         : ").append(sh.getPaymentStatus()).append("\n");
            sb.append("Staff Remarks   : ").append(sh.getRemarks()).append("\n");
            
            // Show technical updates if the technician has added them
            if (sh.getTechnicalNotes() != null && !sh.getTechnicalNotes().trim().isEmpty()) {
                sb.append("Technician Notes: ").append(sh.getTechnicalNotes()).append("\n");
            }
        }
    }
    
    if (!recordsFound) {
        return ""; // Keeps  GUI logic matching if info is empty
    }
    return sb.toString();
}
public static Staff verifyStaffLogin(String inputName, String inputPass) {
    if (allStaff.isEmpty()) {
        loadStaffFromFile();
    }
    
    for (Staff s : allStaff) {
        if (s.getName().equals(inputName) && s.getPassword().equals(inputPass)) {
            return s;
        }
    }
    return null;
}
// check staff logins
public static ArrayList<Staff> allStaff = new ArrayList<>();

// Method to load staff.txt into allStaff list
public static void loadStaffFromFile() {
    allStaff.clear(); 
    try (Scanner s = new Scanner(new File("staff.txt"))) {
        while (s.hasNextLine()) {
            String line = s.nextLine();
            if (line.trim().isEmpty()) continue; 
            
            String[] p = line.split(",");
            if (p.length == 4) {
                String id = p[0];
                String name = p[1];
                String password = p[2];
                String role = p[3];

                // POLYMORPHISM:
                
                if (role.equalsIgnoreCase("Manager")) {
                    allStaff.add(new Manager(id, name, password));
                } else if (role.equalsIgnoreCase("Technician")) {
                    allStaff.add(new Technician(id, name, password));
                } else if (role.equalsIgnoreCase("Counter Staff") || role.equalsIgnoreCase("Staff")) {
                    allStaff.add(new oodjassignment.staff.CounterStaff(id, name, password));
                } else {
                    // If it's anything else create a generic Staff object              
                    allStaff.add(new Staff(id, name, password, role));
                }
                }
            }
        } catch (IOException e) {
          System.out.println("staff.txt not found. Initializing empty list.");
    }
}

//CheckStaffName
public static Staff checkStaffName(String s) {
    for (Staff a : allStaff) {
        if (a.getName().equalsIgnoreCase(s)) {
            return a;
        }
    }
    return null;
}

//Display Staff Details
public static String displayStaffDetails(Staff s) {
    if (s == null) return "Staff not found.";
    return "ID: " + s.id + "\nName: " + s.getName() + "\nRole: " + s.getRole();
}

public static void saveStaffToFile() {
    try (PrintWriter writer = new PrintWriter(new FileWriter("staff.txt"))) {
        for (oodjassignment.staff.Staff s : allStaff) {
            // Format: ID,Name,Password,Role
            String role = "Staff";
            if (s instanceof oodjassignment.staff.Manager) role = "Manager";
            else if (s instanceof oodjassignment.staff.Technician) role = "Technician";
            else if (s instanceof oodjassignment.staff.CounterStaff) role = "Counter Staff";
            
            writer.println(s.getId() + "," + s.getName() + "," + s.getPassword() + "," + role);
        }
        System.out.println("Staff data saved successfully.");
    } catch (IOException e) {
        System.out.println("Error saving staff: " + e.getMessage());
    }
}

public static void savePrices(String normal, String major) {
    try (PrintWriter writer = new PrintWriter(new FileWriter("prices.txt"))) {
        writer.println("NormalService," + normal);
        writer.println("MajorService," + major);
    } catch (IOException e) {
        System.out.println("Error saving prices: " + e.getMessage());
    }
}

// Load comments.txt
public static ArrayList<String> allFeedback = new ArrayList<>();

public static void loadFeedbackFromFile() {
    allFeedback.clear();
    File file = new File("comments.txt");
    if (!file.exists()) return;

    try (Scanner s = new Scanner(file)) { 
        while (s.hasNextLine()) {
            String line = s.nextLine().trim();
            if (!line.isEmpty()) {
                allFeedback.add(line);
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
}

public static ArrayList<ServiceHistories> allServiceHistories = new ArrayList<>();

// Load ServiceHistories.txt
public static void loadServiceHistories() {
    allServiceHistories.clear();
    File file = new File("ServiceHistories.txt");
    if (!file.exists()) return;

    try (Scanner sc = new Scanner(file)) {
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;

            String[] data = line.split(",", -1);
            if (data.length < 8) continue;

            String serviceId = data[0].trim();
            String date = data[1].trim();
            String endDate = "";
            String carPlate = "";
            String customerName = "";
            String technicianId = "";
            String serviceType = "";
            String status = "";
            String paymentStatus = "";
            String remarks = "";
            String customerRemarks = "";
            String technicalNotes = "";

            boolean hasEndDate = data.length >= 10 && data[2].contains(" ");
            boolean looksLikeNewRecord = data.length >= 11 && data[5].startsWith("T") && (data[6].equalsIgnoreCase("Normal")
                    || data[6].equalsIgnoreCase("Major")
                    || data[6].equalsIgnoreCase("GeneralRepair")
                    || data[6].equalsIgnoreCase("Inspection")
                    || data[6].equalsIgnoreCase("InspectionFee"));

            if (looksLikeNewRecord) {
                endDate = data[2].trim();
                carPlate = data[3].trim();
                customerName = data[4].trim();
                technicianId = data[5].trim();
                serviceType = data[6].trim();
                status = data[7].trim();
                paymentStatus = data[8].trim();
                remarks = data[9].trim();
                if (data.length > 10) customerRemarks = data[10].trim();
                if (data.length > 11) technicalNotes = data[11].trim();
            } else if (data.length == 8) {
                carPlate = data[2].trim();
                technicianId = data[3].trim();
                serviceType = data[4].trim();
                status = data[5].trim();
                paymentStatus = data[6].trim();
                remarks = data[7].trim();
            } else if (data.length == 9 && !hasEndDate) {
                carPlate = data[2].trim();
                technicianId = data[3].trim();
                serviceType = data[4].trim();
                status = data[5].trim();
                paymentStatus = data[6].trim();
                remarks = data[7].trim();
                technicalNotes = data[8].trim();
            } else {
                if (hasEndDate) {
                    endDate = data[2].trim();
                    carPlate = data[3].trim();
                    technicianId = data[4].trim();
                    serviceType = data[5].trim();
                    status = data[6].trim();
                    paymentStatus = data[7].trim();
                    remarks = data[8].trim();
                    if (data.length == 10) {
                        technicalNotes = data[9].trim();
                    } else {
                        customerRemarks = data[9].trim();
                        if (data.length > 10) {
                            technicalNotes = data[10].trim();
                        }
                    }
                } else {
                    carPlate = data[2].trim();
                    technicianId = data[3].trim();
                    serviceType = data[4].trim();
                    status = data[5].trim();
                    paymentStatus = data[6].trim();
                    remarks = data[7].trim();
                    if (data.length > 8) {
                        technicalNotes = data[8].trim();
                    }
                }
            }

            ServiceHistories sh = new ServiceHistories(
                    serviceId,
                    date,
                    endDate,
                    carPlate,
                    customerName,
                    technicianId,
                    serviceType,
                    status,
                    paymentStatus,
                    remarks,
                    customerRemarks,
                    technicalNotes.replace("[NL]", "\n")
            );
            allServiceHistories.add(sh);
        }
    } catch (Exception e) {
        System.out.println("Error loading histories: " + e.getMessage());
    }
}

// Load prices.txt
public static void saveAllPrices(String normal, String major, String repair, String inspect) {
    try (PrintWriter writer = new PrintWriter(new FileWriter("prices.txt"))) {
        writer.println("NormalService," + normal);
        writer.println("MajorService," + major);
        writer.println("GeneralRepair," + repair);
        writer.println("InspectionFee," + inspect);
    } catch (IOException e) {
        System.out.println("Error saving prices: " + e.getMessage());
    }
}

public static String generateNextServiceId() {
    int maxNumber = 0;
    for (ServiceHistories sh : allServiceHistories) {
        String id = sh.getServiceId();
        if (id != null && id.startsWith("AP")) {
            try {
                int num = Integer.parseInt(id.substring(2));
                if (num > maxNumber) maxNumber = num;
            } catch (NumberFormatException ignored) {
            }
        }
    }
    return String.format("AP%04d", maxNumber + 1);
}

// Helper method to get service duration in hours
public static int getServiceDuration(String serviceType) {
    if (serviceType == null) return 1;
    if (serviceType.equalsIgnoreCase("Normal")) return 1;
    if (serviceType.equalsIgnoreCase("Major")) return 3;
    if (serviceType.equalsIgnoreCase("GeneralRepair")) return 1;
    if (serviceType.equalsIgnoreCase("InspectionFee") || serviceType.equalsIgnoreCase("Inspection")) return 1;
    return 1;
}

// Helper method to calculate end time based on duration
public static String calculateEndTime(String startDateTime, int durationHours) {
    try {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date startDate = sdf.parse(startDateTime);
        long endTimeMs = startDate.getTime() + (durationHours * 60 * 60 * 1000L);
        Date endDate = new Date(endTimeMs);
        return sdf.format(endDate);
    } catch (Exception e) {
        return startDateTime;
    }
}

// Check if technician has time conflict for appointment
public static boolean hasTimeConflict(String technicianId, String startTime, String endTime) {
    try {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
        Date newStart = sdf.parse(startTime);
        Date newEnd = sdf.parse(endTime);
        
        for (ServiceHistories sh : allServiceHistories) {
            if (sh.getTechnicianId().equalsIgnoreCase(technicianId) && !sh.getStatus().equalsIgnoreCase("Cancelled")) {
                Date existingStart = sdf.parse(sh.getDate());
                Date existingEnd = sdf.parse(sh.getEndDate());
                
                if (newStart.before(existingEnd) && newEnd.after(existingStart)) {
                    return true;
                }
            }
        }
        return false;
    } catch (Exception e) {
        return false;
    }
}

// Get available technicians for appointment time and service type
public static ArrayList<Technician> getAvailableTechnicians(String appointmentDateTime, String serviceType) {
    ArrayList<Technician> available = new ArrayList<>();
    int duration = getServiceDuration(serviceType);
    String endTime = calculateEndTime(appointmentDateTime, duration);
    
    for (Staff s : allStaff) {
        if (s instanceof Technician && !hasTimeConflict(s.getId(), appointmentDateTime, endTime)) {
            available.add((Technician)s);
        }
    }
    return available;
}

// Book appointment and create service history
public static boolean bookAppointment(String customerName, String carPlate, String technicianId, String serviceType, 
                                       String appointmentDateTime, String bookedBy) {
    try {
        if (allServiceHistories.isEmpty()) loadServiceHistories();
        String serviceId = generateNextServiceId();
        int duration = getServiceDuration(serviceType);
        String endDateTime = calculateEndTime(appointmentDateTime, duration);
        String remarks = "Appointment created by " + bookedBy + " for " + customerName;

        ServiceHistories sh = new ServiceHistories(
            serviceId,
            appointmentDateTime,
            endDateTime,
            carPlate,
            customerName,
            technicianId,
            serviceType,
            "Scheduled",
            "Pending",
            remarks,
            "",
            ""
        );
        
        allServiceHistories.add(sh);
        saveServiceHistories();
        return true;
    } catch (Exception e) {
        System.out.println("Error booking appointment: " + e.getMessage());
        return false;
    }
}

// Save all service histories to file
public static void saveServiceHistories() {
    try (PrintWriter writer = new PrintWriter(new FileWriter("ServiceHistories.txt"))) {
        for (ServiceHistories sh : allServiceHistories) {
            String remarks = sh.getRemarks() != null ? sh.getRemarks().replace("\n", "[NL]") : "";
            String customerRemarks = sh.getCustomerRemarks() != null ? sh.getCustomerRemarks().replace("\n", "[NL]") : "";
            String notes = sh.getTechnicalNotes() != null ? sh.getTechnicalNotes().replace("\n", "[NL]") : "";
            String customerName = sh.getCustomerName() != null ? sh.getCustomerName() : "";
            
            writer.println(sh.getServiceId() + "," + 
                          sh.getDate() + "," + 
                          sh.getEndDate() + "," + 
                          sh.getCarPlate() + "," + 
                          customerName + "," + 
                          sh.getTechnicianId() + "," + 
                          sh.getServiceType() + "," + 
                          sh.getStatus() + "," + 
                          sh.getPaymentStatus() + "," + 
                          remarks + "," +
                          customerRemarks + "," +
                          notes);
        }
    } catch (IOException e) {
        System.out.println("Error saving service histories: " + e.getMessage());
    }
}

public static void loadPrices() {
    File file = new File("prices.txt");
    if (!file.exists()) {
        pricesLoaded = true;
        return;
    }
    try (Scanner sc = new Scanner(file)) {
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split(",", -1);
            if (parts.length < 2) continue;
            String key = parts[0].trim();
            String value = parts[1].trim();
            try {
                double price = Double.parseDouble(value);
                if (key.equalsIgnoreCase("NormalService")) {
                    normalServicePrice = price;
                } else if (key.equalsIgnoreCase("MajorService")) {
                    majorServicePrice = price;
                } else if (key.equalsIgnoreCase("GeneralRepair")) {
                    generalRepairPrice = price;
                } else if (key.equalsIgnoreCase("InspectionFee")) {
                    inspectionFee = price;
                }
            } catch (NumberFormatException ignored) {
            }
        }
        pricesLoaded = true;
    } catch (IOException e) {
        System.out.println("Error loading prices: " + e.getMessage());
        pricesLoaded = true;
    }
}

public static double getServicePrice(String serviceType) {
    if (!pricesLoaded) {
        loadPrices();
    }
    if (serviceType == null) return normalServicePrice;
    if (serviceType.equalsIgnoreCase("Major")) return majorServicePrice;
    if (serviceType.equalsIgnoreCase("GeneralRepair")) return generalRepairPrice;
    if (serviceType.equalsIgnoreCase("InspectionFee") || serviceType.equalsIgnoreCase("Inspection")) return inspectionFee;
    return normalServicePrice;
}

public static void loadPaymentHistory() {
    allPhistory.clear();
    File file = new File("PaymentHistory.txt");
    if (!file.exists()) return;
    if (allCust.isEmpty()) {
        loadCustFromFile();
    }
    try (Scanner sc = new Scanner(file)) {
        while (sc.hasNextLine()) {
            String line = sc.nextLine().trim();
            if (line.isEmpty()) continue;
            String[] parts = line.split(",", -1);
            if (parts.length < 5) continue;
            int number;
            int month;
            double amount;
            try {
                number = Integer.parseInt(parts[0].trim());
                month = Integer.parseInt(parts[1].trim());
                amount = Double.parseDouble(parts[3].trim());
            } catch (NumberFormatException e) {
                continue;
            }
            String payeeName = parts[2].trim();
            String serviceId = parts[4].trim();
            Customer payee = checkName(payeeName);
            if (payee == null) {
                payee = new Customer(payeeName, "", "", "", "", "", "", null);
            }
            CustomerPaymentHistory receipt = new CustomerPaymentHistory(number, month, payee, amount, serviceId);
            allPhistory.add(receipt);
        }
    } catch (IOException e) {
        System.out.println("Error loading payment history: " + e.getMessage());
    }
}

public static void savePaymentHistory() {
    try (PrintWriter writer = new PrintWriter(new FileWriter("PaymentHistory.txt"))) {
        for (CustomerPaymentHistory ph : allPhistory) {
            writer.println(ph.getNumber() + "," + ph.getMonth() + "," + ph.getPayee().getName() + "," + ph.getAmount() + "," + ph.getServiceId());
        }
    } catch (IOException e) {
        System.out.println("Error saving payment history: " + e.getMessage());
    }
}

public static CustomerPaymentHistory recordPayment(ServiceHistories sh) {
    if (sh == null || sh.getPaymentStatus().equalsIgnoreCase("Paid")) {
        return null;
    }
    if (allPhistory.isEmpty()) {
        loadPaymentHistory();
    }
    if (allCust.isEmpty()) {
        loadCustFromFile();
    }
    Customer payee = allCust.stream()
            .filter(c -> c.getName().equalsIgnoreCase(sh.getCustomerName())
                    || (c.getCar() != null && c.getCar().getPlateno().equalsIgnoreCase(sh.getCarPlate())))
            .findFirst()
            .orElse(null);
    if (payee == null) {
        return null;
    }
    int nextNumber = allPhistory.stream().mapToInt(CustomerPaymentHistory::getNumber).max().orElse(0) + 1;
    int month = 0;
    try {
        String datePart = sh.getDate().split(" ")[0];
        month = Integer.parseInt(datePart.substring(5, 7));
    } catch (Exception ignored) {
    }
    double amount = getServicePrice(sh.getServiceType());
    CustomerPaymentHistory receipt = new CustomerPaymentHistory(nextNumber, month, payee, amount, sh.getServiceId());
    allPhistory.add(receipt);
    sh.setPaymentStatus("Paid");
    savePaymentHistory();
    return receipt;
}

public static CustomerPaymentHistory findReceiptByServiceId(String serviceId) {
    if (allPhistory.isEmpty()) {
        loadPaymentHistory();
    }
    for (CustomerPaymentHistory ph : allPhistory) {
        if (serviceId != null && serviceId.equalsIgnoreCase(ph.getServiceId())) {
            return ph;
        }
    }
    return null;
}

public static String displayReceipt(CustomerPaymentHistory receipt) {
    if (receipt == null) return "Receipt not found.";
    String payeeName = receipt.getPayee() != null ? receipt.getPayee().getName() : "Unknown";
    return "Receipt ID: " + receipt.getReceiptId() + "\n" +
           "Service ID: " + receipt.getServiceId() + "\n" +
           "Payee: " + payeeName + "\n" +
           "Month: " + receipt.getMonth() + "\n" +
           "Amount: RM" + receipt.getAmount();
}

}
