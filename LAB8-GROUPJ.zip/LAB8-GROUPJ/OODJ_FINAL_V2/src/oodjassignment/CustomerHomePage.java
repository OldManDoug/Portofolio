package oodjassignment;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class CustomerHomePage implements ActionListener {
    JFrame x;
    JButton service, payment, edit, logout, comment, feedback, profile;

    public void actionPerformed(ActionEvent e) {
        try {
            if (e.getSource() == service) {
              //  JOptionPane.showMessageDialog(service, "Customer cannot edit, only read\nRequires Service detail from Technician and CounterStaff");
                
                String servicesInfo = FileHandler.displayServicesForCustomer(StartPage.loggedInCust);//individual service histroy displayed
                if (servicesInfo.isEmpty()) {
                    JOptionPane.showMessageDialog(x, "No service history found for you.", "Service History", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JTextArea textArea = new JTextArea(servicesInfo);
                    textArea.setEditable(false);
                    JScrollPane scrollPane = new JScrollPane(textArea);
                    scrollPane.setPreferredSize(new Dimension(400, 300));
                    JOptionPane.showMessageDialog(x, scrollPane, "Your Service History", JOptionPane.INFORMATION_MESSAGE);
                }
            } else if (e.getSource() == logout) {
                int choice = JOptionPane.showConfirmDialog(logout, "Are you sure you wish to logout?", "", JOptionPane.YES_NO_OPTION);
                if (choice == JOptionPane.YES_OPTION) {
                    StartPage.logoutCustomer();
                    x.setVisible(false); 
                    MainPage.one.setVisible(true); 
                }
            } else if (e.getSource() == payment) {
                FileHandler.loadPaymentHistory(); //loads from file
                String paymentsInfo = FileHandler.displayPaymentsForCustomer(StartPage.loggedInCust);
                if (paymentsInfo.isEmpty()) {
                    JOptionPane.showMessageDialog(x, "No payment history found for you.", "Payment History", JOptionPane.INFORMATION_MESSAGE);
                } else { //viewable by customer
                    JTextArea textArea = new JTextArea(paymentsInfo);
                    textArea.setEditable(false);
                    JScrollPane scrollPane = new JScrollPane(textArea);
                    scrollPane.setPreferredSize(new Dimension(400, 300));
                    JOptionPane.showMessageDialog(x, scrollPane, "Your Payment History", JOptionPane.INFORMATION_MESSAGE);
                }
            } else if (e.getSource() == edit) {
                Customer cust = StartPage.loggedInCust;
                if (cust == null) {
                    JOptionPane.showMessageDialog(x, "You must be logged in to edit your profile.", "Edit Profile", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                JLabel nameLabel = new JLabel(cust.getName());
                JPasswordField passwordField = new JPasswordField(cust.getPassword());
                JTextField phoneField = new JTextField(cust.getPhoneNo());
                JTextField emailField = new JTextField(cust.getEmail());
                JTextField addressField = new JTextField(cust.getAddress());
                JLabel genderLabel = new JLabel(cust.getGender() != null ? cust.getGender() : "");

                //forms format
                    JPanel panel = new JPanel(new GridLayout(0, 1));
                    panel.add(new JLabel("Name:"));
                    panel.add(nameLabel);
                    panel.add(new JLabel("Password:"));
                    panel.add(passwordField);
                    panel.add(new JLabel("Phone Number:"));
                    panel.add(phoneField);
                    panel.add(new JLabel("Email:"));
                    panel.add(emailField);
                    panel.add(new JLabel("Address:"));
                    panel.add(addressField);
                    panel.add(new JLabel("Gender:"));
                    panel.add(genderLabel);
                    
             while(true){
                    int result = JOptionPane.showConfirmDialog(x, panel, "Edit Profile", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                    if (result != JOptionPane.OK_OPTION) {
                        break;
                    }
//profile allow update only password phone email and address  thats all.
                    String password = new String(passwordField.getPassword()).trim();
                    String phone = phoneField.getText().trim();
                    String email = emailField.getText().trim();
                    String address = addressField.getText().trim();

                    if (!StartPage.validatePassword(password)) {
                        JOptionPane.showMessageDialog(x, "Password must be between 8 and 16 characters.", "Error", JOptionPane.ERROR_MESSAGE);
                        continue;
                    }
                    if (!StartPage.validatePhoneNo(phone)) {
                        JOptionPane.showMessageDialog(x, "Phone number must be 10 to 11 digits.", "Error", JOptionPane.ERROR_MESSAGE);
                        continue;
                    }
                    if (!StartPage.validateEmail(email)) {
                        JOptionPane.showMessageDialog(x, "Please enter a valid email address ending with @gmail.com.", "Error", JOptionPane.ERROR_MESSAGE);
                        continue;
                    }
                    if (!StartPage.validateAddress(address)) {
                        JOptionPane.showMessageDialog(x, "Address can only contain letters, numbers, spaces, , / - . (5-100 characters).", "Error", JOptionPane.ERROR_MESSAGE);
                        continue;
                    }
                    cust.setPassword(password);
                    cust.setPhoneNo(phone);
                    cust.setEmail(email);
                    cust.setAddress(address);

                    FileHandler.saveCustomerDtToFile(); //save into database
                    for( Customer updated: FileHandler.allCust){
                   if(updated.getCustID().equals(cust.getCustID())){
                       StartPage.loggedInCust= updated; //refresh session pointing? 
                   } 
    
                    }
                   JOptionPane.showMessageDialog(x, "Profile updated successfully!", "Edit Profile", JOptionPane.INFORMATION_MESSAGE);
                    break;
                }
            } else if (e.getSource() == comment) {
                // FIXED: Linked the feedback entry structure with active customer's car plate details 
                Customer loggedIn = StartPage.loggedInCust;
                if (loggedIn == null || loggedIn.getCar() == null || loggedIn.getCar().getPlateno().trim().isEmpty()) {
                    JOptionPane.showMessageDialog(x, "Error: Unable to submit comment without an associated car plate record.", "Profile Unresolved", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                JTextArea commentArea = new JTextArea(6, 30);
                commentArea.setLineWrap(true);
                commentArea.setWrapStyleWord(true);
                JScrollPane scrollPane = new JScrollPane(commentArea);
                JPanel commentPanel = new JPanel(new BorderLayout(8, 8));
                commentPanel.add(new JLabel("Enter your operational remarks/requests for the technical team:"), BorderLayout.NORTH);
                commentPanel.add(scrollPane, BorderLayout.CENTER);

                int commentResult = JOptionPane.showConfirmDialog(x, commentPanel, "Submit Comment Log", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
                if (commentResult == JOptionPane.OK_OPTION) {
                    String commentText = commentArea.getText().trim();
                    if (!commentText.isEmpty()) {
                        String cleanPlate = loggedIn.getCar().getPlateno().trim().toUpperCase();
                        
                        // Saves exactly what the search key checks in TechnicianHomePage: "REMARK - Plate: XYZ | Details: ..."
                        FileHandler.saveComment("REMARK - Plate: " + cleanPlate + " | Details: " + commentText);
                        JOptionPane.showMessageDialog(x, "Comment successfully relayed to technicians!", "Success", JOptionPane.INFORMATION_MESSAGE);
                    } else {
                        JOptionPane.showMessageDialog(x, "Please enter a valid comment string.", "Validation Check", JOptionPane.WARNING_MESSAGE);
                    }
                }
            } else if (e.getSource() == feedback) {
                FileHandler.loadFeedbackFromFile();
                FileHandler.loadServiceHistories();
                
                Customer loggedIn = StartPage.loggedInCust;
                String customerPlate = (loggedIn != null && loggedIn.getCar() != null) ? loggedIn.getCar().getPlateno().trim().toUpperCase() : "";
                
                StringBuilder feedbackBuilder = new StringBuilder();
                int matchCount = 0;

                for (String line : FileHandler.allFeedback) {
                    if (line.contains("FINAL SOLUTION - Service ID:")) {
                        try {
                            String targetServiceId = line.substring(line.indexOf("Service ID:") + 11, line.indexOf("| Tech:")).trim();
                            String techName = line.substring(line.indexOf("| Tech:") + 7, line.indexOf("| Details:")).trim();
                            
                            for (var sh : FileHandler.allServiceHistories) {
                                if (sh.getServiceId().equalsIgnoreCase(targetServiceId)) {
                                    if (sh.getCarPlate().trim().toUpperCase().equals(customerPlate) || 
                                        sh.getCustomerName().equalsIgnoreCase(loggedIn.getName())) {
                                        
                                        feedbackBuilder.append("📝 Resolution Details: ").append(techName).append("\n\n")
                                                       .append(line.substring(line.indexOf("Details:") + 8).trim()).append("\n")
                                                       .append("--------------------------------------------------\n\n");
                                        matchCount++;
                                    }
                                }
                            }
                        } catch (Exception ex) {
                            // Skip line read errors gracefully
                        }
                    }
                }

                if (matchCount == 0) {
                    JOptionPane.showMessageDialog(x, "No technical appointment feedback available yet.", "Appointment Feedback", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JTextArea textArea = new JTextArea(feedbackBuilder.toString());
                    textArea.setEditable(false);
                    JScrollPane scrollPane = new JScrollPane(textArea);
                    scrollPane.setPreferredSize(new Dimension(460, 320));
                    JOptionPane.showMessageDialog(x, scrollPane, "Your Appointment Resolutions", JOptionPane.INFORMATION_MESSAGE);
                }
                
            } else if (e.getSource() == profile) {
                //FileHandler.loadCustFromFile(); Allows to see the updated profile present 
                Customer cust = StartPage.loggedInCust;

                if (cust == null) {
                    JOptionPane.showMessageDialog(x, "No customer details found.", "Profile", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JPanel infoPanel = new JPanel(new GridLayout(0, 1, 4, 4));
                    infoPanel.add(new JLabel("Customer ID: " + (cust.getCustID() != null ? cust.getCustID() : "")));
                    infoPanel.add(new JLabel("Name: " + (cust.getName() != null ? cust.getName() : "")));
                    infoPanel.add(new JLabel("Email: " + (cust.getEmail() != null ? cust.getEmail() : "")));
                    infoPanel.add(new JLabel("Phone: " + (cust.getPhoneNo() != null ? cust.getPhoneNo() : "")));
                    infoPanel.add(new JLabel("Address: " + (cust.getAddress() != null ? cust.getAddress() : "")));
                    infoPanel.add(new JLabel("Gender: " + (cust.getGender() != null ? cust.getGender() : "")));
                    String plate = "";
                    if (cust.getCar() != null && cust.getCar().getPlateno() != null) plate = cust.getCar().getPlateno();
                    infoPanel.add(new JLabel("Car Plate: " + plate));

                    JScrollPane scrollPane = new JScrollPane(infoPanel);
                    scrollPane.setPreferredSize(new Dimension(420, 260));
                    JOptionPane.showMessageDialog(x, scrollPane, "Your Profile", JOptionPane.INFORMATION_MESSAGE);
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(x, "Invalid Input!", "", JOptionPane.ERROR_MESSAGE);
        }
    }

    public CustomerHomePage() {
        x = new JFrame("Customer Dashboard");
        x.setSize(520, 420);
        x.setLocationRelativeTo(null);
        x.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        String welcomeName = "Customer";
        if (StartPage.loggedInCust != null) {
            welcomeName = StartPage.loggedInCust.getName();
        }

        JLabel title = new JLabel("Welcome, " + welcomeName, JLabel.CENTER);
        title.setFont(new Font("Arial", Font.BOLD, 20));
        title.setBorder(BorderFactory.createEmptyBorder(18, 18, 12, 18));

        service = new JButton("View Service History");
        payment = new JButton("View Payment History");
        edit = new JButton("Edit Profile");
        profile = new JButton("View Profile");
        comment = new JButton("Submit Comment");
        feedback = new JButton("View Appointment Feedback");
        logout = new JButton("Logout");
//add buttons
        service.addActionListener(this);
        edit.addActionListener(this);
        logout.addActionListener(this);
        payment.addActionListener(this);
        comment.addActionListener(this);
        feedback.addActionListener(this);
        profile.addActionListener(this);

        JPanel buttonPanel = new JPanel(new GridLayout(0, 2, 12, 12));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(16, 20, 16, 20));
        buttonPanel.add(profile);
        buttonPanel.add(edit);
        buttonPanel.add(service);
        buttonPanel.add(payment);
        buttonPanel.add(comment);
        buttonPanel.add(feedback);
        buttonPanel.add(logout);
// Formatiing
        x.setLayout(new BorderLayout());
        x.add(title, BorderLayout.NORTH);
        x.add(buttonPanel, BorderLayout.CENTER);
        x.setVisible(true); 
    }
}

   
   
