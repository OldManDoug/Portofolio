package oodjassignment;
import oodjassignment.staff.CounterStaff;
import java.util.ArrayList;
import java.util.Scanner;

public class Customer{
	/*Data*/
	private String customerID; 
	private String Name;
	private String password;
	private String phoneNo;
	private String email;
        private String gender;
        private String address; 
        private ArrayList <CustomerPaymentHistory> allPHistory = new ArrayList<>();
       public static ArrayList<CustomerServiceHistory> allHistory = new ArrayList<CustomerServiceHistory>();
       //Comments - in here needed then one for FileHandler
     
	//No need to appear in the UML class diagram
	//Need to concatenate with the fixed character
	private Customer nextCust;
        private Car car; // as a class of 
        private CounterStaff cstaff; //- because association one customer meet one or many counterstaff. 
    private static Customer firstCust = null; // Static variable to keep the first supplier
    private static int idCounter = 1; // Static counter for ID generation
    private static Customer loggedInCust = null;  // Track the currently logged-in admin
    
    Scanner scan = new Scanner(System.in);
	
	//Constructors
    public Customer() {
    	//no-arg constructor
    	this(" ", " "," "," "," "," "," ",null);
    }
    //button for appointments from Car class, use Service Histories txt to pass and call the code msg him by teams 
    //Constructor with args
    public Customer(String Name, String password,String phoneNo, String email,String gender, String address, Car car) {
    
    	customerID = generateCustomerID();
    	this.Name = Name;
    	this.password = password;
    	this.phoneNo = phoneNo;
    	this.email = email;
        this.gender = gender;
        this.address = address;
        this.car = car;
    	this.nextCust = null;
    }
    //create a Car a = new Car () -- then put all the car details then put the customer inside. Lecture 5  put the car
    // Constructor for loading from file
    public Customer(String customerID, String Name, String password, String phoneNo, String email,String gender, String address, Car car) {
        this.customerID = customerID;
        this.Name = Name;
    	this.password = password;
    	this.phoneNo = phoneNo;
    	this.email = email;
        this.gender = gender;
        this.address = address;
        this.car = car;
    	this.nextCust = nextCust;
    }
    
    // Method to generate a AdminID
    private static String generateCustomerID() {
        return "CUST" + String.format("%03d", idCounter++);
    }
    
    //Getters(accesor)
    public String getCustID(){
    	return customerID;
    }
    
    public String getName(){
    	return Name;
    }
    
    public String getPassword(){
    	return password;
    }
    
    public String getPhoneNo(){
    	return phoneNo;
    }
    
    public String getEmail(){
        return email;
    }

    public String getGender() {
        return gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
    
    
    //Setters(mutator)
    public void setName(String Name){
    	this.Name = Name;
    }

    public Car getCar() {
        return car; // how to get back the car plate no/model that belong to him? 
    }
    
    public void setPassword(String password){
    	this.password = password;
    }
    
    public void setPhoneNo(String phoneNo){
    	this.phoneNo = phoneNo;
    }
    
    public void setEmail(String email){
        this.email = email;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }
    
    // Static method to get the first admin
    public static Customer getFirstCust() {
        return firstCust;
    }

    public static int getIdCounter() {
        return idCounter;
    }

    public static void setIdCounter(int counter) {
        if (counter > idCounter) {
            idCounter = counter;
        }
    }
    
    public Customer getNextCust() {
        return nextCust;
    }

    public void setNextCust(Customer nextCust) {
        this.nextCust = nextCust;
    }

    public void setCar(Car car) {
        this.car = car;
    }
  // end of the single class  
   
    //Overriding method
    //overriden equals method
    //to check if customerID and password matched or not
    @Override
    public boolean equals(Object o) {
        // Method header is fixed!!
        if (this == o) {
            return true; //return true if the object has same reference
        }

        if (o == null || !(o instanceof Customer)) {
            return false; // return false if the object is null or not the same type
        }

        // Cast the object to Customer
        Customer adm = (Customer) o;

        // Compare customerID and password using .equals() method
        // Used in login() to identify the admin
        if (this.customerID.equals(adm.customerID) && this.password.equals(adm.password)) {
            return true;
        } else {
            return false;
        }
    }
    
    @Override
    public String toString(){
    	return "\nCustomer ID: " + customerID +
    		   "\nCustomer Name: " + Name +
    		   "\nPassword: " + password +
    		   "\nPhone Number: " + phoneNo +
    		   "\nEmail: " + email +
                   "\nGender:"+ gender +
                   "\nAddress:"+ address +
                   "\nPlateNumber:"+car.getPlateno()+
                   "\nModel:"+car.getModel();
    }
    public String toString1(){ //override toString mayhaps
    	return 
                   "\nCarDetails:"+car.toString()+"\n";
    }
}

