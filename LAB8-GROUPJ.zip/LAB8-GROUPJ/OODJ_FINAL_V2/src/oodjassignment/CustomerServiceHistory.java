package oodjassignment;
/**
Service history = Date of service,vehicle mileage (and plate no to relate to owner)
* details of what happened(maintenance)- from Technician,Technician name   
 record of 
 */
import java.time.*;
//libraries and GUI 

public class CustomerServiceHistory {
    public YearMonth servdate;
    private int number; //or make this into year and month? 
    private Customer Name;
    private Car car;
   // private Technician tech;

    public CustomerServiceHistory() {
    this (0,null,null);
    }

    public CustomerServiceHistory(YearMonth servdate, Customer payee, Car car) {
        this.servdate = servdate;
        this.Name = payee;
        this.car = car;
    }
    //one for X one for something else.
    public CustomerServiceHistory(int number,YearMonth servdate,Car car){ //Admin staff) {
        this.number = number;        
        this.servdate = servdate;
        this.car = car;
       // this.tech = tech;
    }
    public int getNumber() {
        return number;
    }
    public void setNumber(int number) {
        this.number = number;
    }
    public YearMonth getYearMonth() {
        return servdate; 
    }

    public void setServdate(YearMonth servdate) {
        this.servdate = servdate;
    }

    public Customer getName() {
        return Name;
    }
    public void setName(Customer name) {
        this.Name = name;
    }
   /* public Admin getStaff() {
        return staff;
    }
    public void setStaff(Admin staff) {
        this.staff = staff;
    }
    */
    public String getCar() {
        return car.plateno;
    }
    public void setCar(Car car) {
        this.car = car;
    }
    //toString? 
}
