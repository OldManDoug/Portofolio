package oodjassignment;

public class MainPage {
    public static StartPage one; 
    public static CustomerHomePage two; 
    
    public static void main(String[] args) {
        // Load ALL data immediately so the app is ready
        FileHandler.loadCustFromFile();
        FileHandler.loadStaffFromFile();
        
        one = new StartPage();
        one.setVisible(true); 
       
    }    
}
