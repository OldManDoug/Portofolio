package oodjassignment;
/**
 *	Edit personal / individual profile. 
  	Access individual service and payment histories.
  	Access feedbacks of individual appointments.
  	Provide comments for counter staff and technicians involved in individual appointments.
 */
//libraries and GUI 
/*Paymet history should include? DONE BU COUNTER STAFF 
*/
public class CustomerPaymentHistory {

    private int number;
    private int month;
    private Customer payee; // based on the customer (individual payment history)
    private Car car;
    private String serviceId;
    private double amount;
    private String receiptId;

    public CustomerPaymentHistory(int number, int month, Customer payee) {
        this.number = number;
        this.month = month;
        this.payee = payee;
        this.amount = 0.0;
        this.serviceId = "";
        this.receiptId = String.format("R%03d", number);
    }

    public CustomerPaymentHistory(int number, int month, Customer payee, double amount, String serviceId) {
        this.number = number;
        this.month = month;
        this.payee = payee;
        this.amount = amount;
        this.serviceId = serviceId;
        this.receiptId = String.format("R%03d", number);
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public Customer getPayee() {
        return payee;
    }

    public void setPayee(Customer payee) {
        this.payee = payee;
    }

    public String getServiceId() {
        return serviceId;
    }

    public void setServiceId(String serviceId) {
        this.serviceId = serviceId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getReceiptId() {
        return receiptId;
    }

    public void setReceiptId(String receiptId) {
        this.receiptId = receiptId;
    }

    public void setCar(Car car) {
        this.car = car;
    }

    public Car getCar() {
        return car;
    }

    @Override
    public String toString() {
        return "CustomerPaymentHistory is:{" + "number=" + number + ", month=" + month + ", payee=" + payee + ", car=" + car + '}';
    }
}
