package oodjassignment;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.*;
import javax.swing.JOptionPane;
/**
 * THIS IS THE LOGIN PART?/ REGISTER 
 * @author ProfT
 */
public class StartPage extends JFrame implements ActionListener{
 private static Customer firstCust = null; // Static variable to keep the first supplier
    private static int idCounter = 1; // Static counter for ID generation
    static Customer loggedInCust = null;  // Track the currently logged-in admin

//Validation methods
    // Method to validate contact number (must be 10 or 11 digits)
    public static boolean validatePhoneNo(String phoneNo) {
        return (phoneNo.length() == 10 || phoneNo.length() == 11) && phoneNo.matches("\\d+");
    }
    //Method to validate email (must end with @gmail.com)
    public static boolean validateEmail(String email) {
    	return email.matches("^[a-zA-Z0-9._%+-]+@gmail\\.com$");
	}	
	//Method to validate user password
	//Min 8 chars; max 16 chars
	//Combination of numbers, chars, and special chars
	public static boolean validatePassword(String password) {
    	return password.length() >= 8 && password.length() <= 16 ; //&& password.matches("^(?=.*[a-zA-Z])(?=.*\\d)[a-zA-Z\\d]{8,16}$");
	} //maybe remove the regex part.  try 
        public static boolean validateGender(String gender){
            return gender.equals("Male")|| gender.equals("Female");
            //only accepts Male and Female
            }
        public static boolean isValidName(String name) {
        if (name == null || name.trim().isEmpty()) {
            return false;
        }
        // Name must contain only letters and be 1-30 characters long
        String regex = "^[A-Za-z]{1,30}$";
        return name.matches(regex);
    }
        public static boolean validateAddress(String address){
         if (address == null || address.trim().isEmpty()) {
            return false; }
        // Allow: letters, numbers, spaces, commas (,), slashes (/), hyphens (-), periods (.)
        String regex = "^[A-Za-z0-9\\s,./-]{5,100}$";
            return address.matches(regex);
        }
        public static boolean validateCarPlate(String plate) {
            if (plate == null || plate.trim().isEmpty()) {
                return false;
            }
            return plate.matches("^(?=.*[A-Z])(?=.*\\d)[A-Z0-9]{2,13}$");
        }
     private JButton loginButton, exitButton;

    public StartPage() {
        setTitle("Customer Start Page");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JLabel title = new JLabel("Welcome, please Log In to use our services", JLabel.CENTER);
        title.setFont(new java.awt.Font("Arial", java.awt.Font.BOLD, 18));
        title.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        loginButton = new JButton("Log In");
        exitButton = new JButton("Exit");

        loginButton.setPreferredSize(new java.awt.Dimension(220, 60));
        exitButton.setPreferredSize(new java.awt.Dimension(220, 50));

        loginButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 16));
        exitButton.setFont(new java.awt.Font("Arial", java.awt.Font.PLAIN, 16));

        loginButton.addActionListener(this);
        exitButton.addActionListener(this);

        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
        exitButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel centerPanel = new JPanel();
        centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.Y_AXIS));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        centerPanel.add(title);
        centerPanel.add(Box.createVerticalStrut(20));
        centerPanel.add(loginButton);
        centerPanel.add(Box.createVerticalStrut(15));
        centerPanel.add(exitButton);

        setLayout(new BorderLayout());
        add(centerPanel, BorderLayout.CENTER);

        setVisible(true); //viewsable. 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == loginButton) {
            loginCustomer();
        } else if (e.getSource() == exitButton) {
            int choice = JOptionPane.showConfirmDialog(exitButton, "Are you sure you want to exit",
                    "ExitConfirmation",JOptionPane.YES_NO_OPTION);
            if(choice == 0){ //IF YES
            JOptionPane.showMessageDialog(exitButton,"Thank you and have a nice day",
                    "Bye",JOptionPane.INFORMATION_MESSAGE);
            System.exit(0);
            //IF not, they stay in hwew. 
        }
        }
    }
     // Method to REGISTER with validation
public Customer signUpCust() {
    JTextField nameField = new JTextField();
    JPasswordField passwordField = new JPasswordField();
    JTextField phoneField = new JTextField();
    JTextField emailField = new JTextField();
    JRadioButton maleRadio = new JRadioButton("Male");
    JRadioButton femaleRadio = new JRadioButton("Female");
    ButtonGroup genderGroup = new ButtonGroup();
    genderGroup.add(maleRadio);
    genderGroup.add(femaleRadio);
    JTextField addressField = new JTextField();
    JTextField carPlateField = new JTextField();

    while (true) {
        Object[] inputs = {
            "Name:", nameField,
            "Password:", passwordField,
            "Phone:", phoneField,
            "Email:", emailField,
            "Address:", addressField,
            "Car Plate:", carPlateField,
            "Gender:", new Object[]{maleRadio, femaleRadio}
                
        };

        int option = JOptionPane.showConfirmDialog(this, inputs, "Register New Customer", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option != JOptionPane.OK_OPTION) {
            return null;
        }

        String name = nameField.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        String phoneNo = phoneField.getText().trim();
        String email = emailField.getText().trim();
        String address = addressField.getText().trim();
        String carPlate = carPlateField.getText().trim().toUpperCase();
        String gender = maleRadio.isSelected() ? "Male" : femaleRadio.isSelected() ? "Female" : "";
        if (!isValidName(name)) {
            JOptionPane.showMessageDialog(this, "Name must contain only letters, up to 30 characters.", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        FileHandler.loadCustFromFile();
        if (FileHandler.isActiveCustomerNameTaken(name, null)) {
            JOptionPane.showMessageDialog(this, "This customer name is already used by an existing customer.", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        if (!validatePassword(password)) {
            JOptionPane.showMessageDialog(this, "Password must be between 8 and 16 characters.", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        if (!validatePhoneNo(phoneNo)) {
            JOptionPane.showMessageDialog(this, "Phone number must be 10 to 11 digits.", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        if (!validateEmail(email)) {
            JOptionPane.showMessageDialog(this, "Please enter a valid email address ending with @gmail.com.", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        if (!validateGender(gender)) {
            JOptionPane.showMessageDialog(this, "Gender must be Male or Female.", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        if(!validateAddress(address)){
            JOptionPane.showMessageDialog(this, "Address can only contain letters, numbers, spaces, , / - . (5-100 characters).", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        if (!validateCarPlate(carPlate)) {
            JOptionPane.showMessageDialog(this, "Car plate must be 2-13 characters long, contain letters and digits, and include at least one of each.", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        if (FileHandler.isCarPlateTaken(carPlate)) {
            JOptionPane.showMessageDialog(this, "This car plate is already assigned to another customer.", "Error", JOptionPane.ERROR_MESSAGE);
            continue;
        }
        Customer newCust = new Customer(name, password, phoneNo, email, gender, address, null);
        Car car1 = new Car(carPlate, "", "", 0.0, 0, 0, newCust);
        newCust.setCar(car1);
        if (firstCust == null) {
            firstCust = newCust;
        } else {
            Customer currentCust = firstCust;
            while (currentCust.getNextCust() != null) {
                currentCust = currentCust.getNextCust();
            }
            currentCust.setNextCust(newCust);
        }
        // Keep the persistent customer list in sync so the record is saved correctly.
        FileHandler.allCust.add(newCust);

        JOptionPane.showMessageDialog(this, "New Account Created SUCCESSFULLY!", "Success", JOptionPane.INFORMATION_MESSAGE);
        FileHandler.saveCustomerDtToFile();
        return newCust;
    }
}
// Method for Customer Login
public void loginCustomer() {
    // 1. Get input
    String inputName = JOptionPane.showInputDialog("Enter your name:");
    if (inputName == null) return; 

    JPasswordField passwordField = new JPasswordField(16);
    char defaultEcho = passwordField.getEchoChar();

    JToggleButton toggle = new JToggleButton("👁");
    toggle.setFocusable(false);
    toggle.setMargin(new java.awt.Insets(2, 6, 2, 6));
    toggle.setToolTipText("Show password");
    toggle.addActionListener(evt -> {
        boolean show = toggle.isSelected();
        passwordField.setEchoChar(show ? (char) 0 : defaultEcho);
        toggle.setText(show ? "🙈" : "👁");
        toggle.setToolTipText(show ? "Hide password" : "Show password");
    });

    JPanel passPanel = new JPanel(new BorderLayout(6, 0));
    passPanel.add(passwordField, BorderLayout.CENTER);
    passPanel.add(toggle, BorderLayout.EAST);

    int passChoice = JOptionPane.showConfirmDialog(
            this,
            new Object[]{"Enter Password:", passPanel},
            "Login",
            JOptionPane.OK_CANCEL_OPTION,
            JOptionPane.PLAIN_MESSAGE
    );
    if (passChoice != JOptionPane.OK_OPTION) return;
    String inputPass = new String(passwordField.getPassword());

    // 2. Check the Staff.txt
    oodjassignment.staff.Staff s = FileHandler.verifyStaffLogin(inputName, inputPass);
    
    if (s != null) {
        if (s instanceof oodjassignment.staff.Manager) {
            JOptionPane.showMessageDialog(this, "Manager Login Successful! Welcome, " + s.getName());
            this.dispose();
            oodjassignment.staff.Manager mgr = (oodjassignment.staff.Manager) s;

            new oodjassignment.staff.ManagerHomePage(mgr).setVisible(true);
            return; 
            
        } else if (s instanceof oodjassignment.staff.Technician) {
            JOptionPane.showMessageDialog(this, "Technician Login Successful! Welcome, " + s.getName());
            this.dispose();
            new oodjassignment.staff.TechnicianHomePage((oodjassignment.staff.Technician) s).setVisible(true);
            return;
        } else if (s instanceof oodjassignment.staff.CounterStaff) {
            JOptionPane.showMessageDialog(this, "Counter Staff Login Successful! Welcome, " + s.getName());
            this.dispose();
            new oodjassignment.staff.CounterStaffHomePage((oodjassignment.staff.CounterStaff) s).setVisible(true);
            return;
        }
    }

    // 3. Check the Customer customers.txt
    FileHandler.loadCustFromFile();
    Customer current = FileHandler.firstCust; 
    
    while (current != null) {
        if (current.getName().equalsIgnoreCase(inputName) && current.getPassword().equals(inputPass)) {
            loggedInCust = current;
            JOptionPane.showMessageDialog(this, "Customer Login Successful! Welcome, " + current.getName());
            
            this.dispose(); 
            MainPage.two = new CustomerHomePage(); 
            MainPage.two.x.setVisible(true);      
            return;
        }
        current = current.getNextCust();
    }

    // 4. Else
    JOptionPane.showMessageDialog(this, "Invalid Name or Password.", "Login-ERROR", JOptionPane.ERROR_MESSAGE);
}

public static void logoutCustomer() {
        if (loggedInCust != null) {
            System.out.println("Customer " + loggedInCust.getName() + " logged out.");
            loggedInCust = null;
        }
    }
}



         /* Customer currentCustomer = firstCust;
        while (currentCustomer != null) {
            String name = JOptionPane.showInputDialog(
                        "Enter your name:");
        String password = JOptionPane.showInputDialog(
                        "Enter Password:");
            if (currentCustomer.getName().equals(name) && currentCustomer.getPassword().equals(password)) {
                loggedInCust = currentCustomer;
                JOptionPane.showMessageDialog(null,"Login Successful! Welcome, " + currentCustomer.getName() + ".","Customer Has Login",JOptionPane.PLAIN_MESSAGE);
                CustomerHomePage(); //after login successful, i want to go to customerhome page. 
                return currentCustomer;        
            }else{
             JOptionPane.showMessageDialog(null,"Invalid Name or Password.","Login-ERROR" , JOptionPane.ERROR_MESSAGE);
          JOptionPane.showConfirmDialog(null, "Would you like to Continue ? ","Hint", JOptionPane.YES_NO_OPTION);
        
        // allow for looping
        if(JOptionPane.YES_NO_OPTION ==1){
           loginCustomer(); //back here - that is if it is a Yes
        }else{
        JLabel l = new JLabel("If you still cannot login, you are advised to proceed to REGISTER");
        Button b = new Button("Click Me to go Register");
        //How to call constructor from class again? 
         c.signUpCust(); 
        }   // third try -Please register.      
       }
           // transit to a new page
        }
         return null;
    */
   
    

